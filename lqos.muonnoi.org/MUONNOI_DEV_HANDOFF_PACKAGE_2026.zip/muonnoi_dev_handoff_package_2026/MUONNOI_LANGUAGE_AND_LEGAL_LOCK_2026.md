# MUÔN NƠI · LANGUAGE AND LEGAL LOCK 2026
**File khóa chuẩn ngôn ngữ + pháp lý cho DEV / Content / Design / Founder**  
**Ngày:** 2026-05-11  
**Trạng thái:** Internal lock · Legal review required before public investment publication

---

## 1. Mục tiêu file

File này khóa toàn bộ chuẩn ngôn ngữ và ranh giới pháp lý cho hệ `muonnoi.org`, đặc biệt các trang:

```txt
muonnoi.org
duan.muonnoi.org
dautu.muonnoi.org
partners.muonnoi.org
quests / Life Quest OS
```

Mọi nội dung public, CTA, investor page, project registry, deck, form, email, landing page phải bám file này.

---

## 2. Nền pháp lý đã nghiên cứu ở mức định hướng

> Ghi chú: Phần này không thay thế ý kiến của luật sư. Trước khi public trang đầu tư hoặc nhận tiền, team bắt buộc phải có legal review riêng.

### 2.1. Chào bán cổ phần riêng lẻ của công ty cổ phần không đại chúng

Theo Luật Doanh nghiệp Việt Nam 2020, Điều 125 về chào bán cổ phần riêng lẻ của công ty cổ phần không đại chúng yêu cầu việc chào bán không được thực hiện qua phương tiện thông tin đại chúng và chào bán cho dưới 100 nhà đầu tư, không kể nhà đầu tư chứng khoán chuyên nghiệp, hoặc chỉ chào bán cho nhà đầu tư chứng khoán chuyên nghiệp.

Nguồn tham chiếu:
- Law on Enterprises 2020, Article 125: https://english.luatvietnam.vn/law-on-enterprises-no-59-2020-qh14-dated-june-17-2020-of-the-national-assembly-186272-doc1.html
- LawNet summary of Article 125: https://lawnet.vn/thong-tin-phap-luat/en/chinh-sach-moi/vietnam-regulations-on-private-placement-of-shares-from-january-1-2021-147480.html

### 2.2. Chào bán chứng khoán ra công chúng

Theo Luật Chứng khoán Việt Nam 2019, chào bán chứng khoán ra công chúng bao gồm trường hợp chào bán qua phương tiện thông tin đại chúng, chào bán cho từ 100 nhà đầu tư trở lên không kể nhà đầu tư chứng khoán chuyên nghiệp, hoặc chào bán cho số lượng nhà đầu tư không xác định. Luật cũng quy định các điều kiện, hồ sơ đăng ký, bản cáo bạch và thủ tục với Ủy ban Chứng khoán Nhà nước.

Nguồn tham chiếu:
- Law on Securities 2019, definitions and public offering articles: https://english.luatvietnam.vn/law-on-securities-no-54-2019-qh14-dated-november-26-2019-of-the-national-assembly-179050-doc1.html

### 2.3. Hệ quả cho `dautu.muonnoi.org`

Vì trang web là phương tiện công khai, trang `dautu.muonnoi.org` KHÔNG được viết như một lời chào bán cổ phần/chứng khoán công khai nếu chưa có hồ sơ pháp lý, bản cáo bạch, thủ tục phê duyệt, tư vấn pháp lý và điều kiện nhà đầu tư tương ứng.

Trang đầu tư chỉ được viết theo hướng:

```txt
Giới thiệu hệ sinh thái
Giới thiệu nhu cầu đồng hành
Mời cá nhân/tổ chức/doanh nghiệp/quỹ đăng ký quan tâm
Lọc nhà đầu tư phù hợp
Chuyển vào cổng riêng sau xác minh
Cung cấp tài liệu chi tiết trong môi trường gated/private
Không nhận tiền qua public page nếu chưa có hợp đồng và pháp lý đầy đủ
```

---

## 3. Những câu/từ bị cấm trên public investment pages

Không dùng:

```txt
cam kết lợi nhuận
đảm bảo hoàn vốn
đầu tư chắc thắng
lợi nhuận thụ động đảm bảo
mua cổ phần ngay trên website
chốt suất đầu tư
số lượng suất có hạn tạo FOMO
ROI chắc chắn
x lần tài khoản
định giá chắc chắn sẽ tăng
đầu tư không rủi ro
ai tham gia cũng có tiền
chào bán cổ phần công khai
huy động vốn công khai
```

Không dùng tiếng Anh:

```txt
guaranteed return
risk-free investment
sure profit
guaranteed ROI
passive income guaranteed
buy shares now
public securities offering
last chance to invest
limited slots unless legally cleared
```

---

## 4. Những câu được phép dùng

Được dùng:

```txt
đăng ký quan tâm
nhận hồ sơ giới thiệu sau khi xác minh phù hợp
gặp đội sáng lập
trở thành đối tác chiến lược
đồng hành xây dựng hệ sinh thái
cơ hội hợp tác
cơ hội đầu tư sẽ được xem xét theo từng hồ sơ
thông tin chi tiết chỉ cung cấp trong cổng riêng sau legal/KYC review
không phải lời chào bán chứng khoán công khai
không cam kết lợi nhuận
nhà đầu tư cần tự đánh giá rủi ro
```

Tiếng Anh được dùng:

```txt
register interest
request an introductory dossier
meet the founding team
become a strategic partner
partnership opportunity
investment interest review
private gated investor review
not a public securities offering
no guaranteed return
independent legal and financial review required
```

---

## 5. Disclaimer bắt buộc trên `dautu.muonnoi.org`

### Bản tiếng Việt

Thông tin trên trang này chỉ nhằm giới thiệu định hướng, hệ sinh thái và cơ hội đồng hành. Đây không phải lời chào bán chứng khoán, không phải cam kết lợi nhuận, không phải bảo đảm hoàn vốn và không thay thế tư vấn pháp lý, tài chính hoặc đầu tư độc lập.

Nhà đầu tư cần tự đánh giá rủi ro, năng lực tài chính và mức độ phù hợp trước khi tham gia. Các hồ sơ chi tiết chỉ được cung cấp trong cổng đầu tư riêng sau khi hoàn tất xác minh phù hợp và tuân thủ quy trình pháp lý áp dụng.

### English

The information on this page is provided for ecosystem introduction and partnership interest only. It is not a public securities offering, not a guarantee of return, not a guarantee of capital recovery, and not a substitute for independent legal, financial, or investment advice.

Prospective investors must assess their own risk tolerance, financial capacity, and suitability before participating. Detailed materials are only provided through a private investor review process after suitability verification and applicable legal procedures.

---

## 6. Chuẩn ngôn ngữ public site `muonnoi.org`

Public site phải dùng ngôn ngữ:

```txt
calm
precise
real
long-term
non-sales
human-centered
trust-first
proof-based
```

Không dùng ngôn ngữ:

```txt
hype
thổi phồng
mơ hồ
thần kỳ
đổi đời nhanh
kiếm tiền nhanh
đầu tư chắc thắng
viral bằng mọi giá
```

---

## 7. Khóa định vị chính

### Tiếng Việt

Muôn Nơi là hạ tầng số cho đời sống thật — nơi học tập, làm việc, du lịch, gia đình, sức khỏe, sáng tạo và đóng góp cộng đồng diễn ra với bằng chứng thật, mối quan hệ thật và giá trị thật.

### English

Muôn Nơi is digital infrastructure for real life — where learning, work, travel, family, health, creation, and community contribution happen with verified proof, real relationships, and real value.

---

## 8. Khóa tagline

### Chính

Tự Do Tuyệt Đối Từ Bên Trong, Trách Nhiệm Rõ Ràng Trong Đời Sống Muôn Nơi.

### Phụ

```txt
Sống thật. Học thật. Làm thật. Tạo giá trị thật.
Internet trở lại với con người.
Đi ra thế giới thật. Gặp người thật. Sống đời thật.
Hệ điều hành cho đời sống, không cho thời gian màn hình.
```

---

## 9. Quy tắc cho Life Quest OS

Không gọi là “play to earn”.

Gọi là:

```txt
Life Quest OS
Hệ nhiệm vụ đời sống
Chơi để sống tốt hơn
Play → Learn → Build → Prove → Grow
Earn by real value
```

Không nói:

```txt
ai chơi cũng có tiền
chơi là kiếm tiền
đổi đời khi chơi
```

Được nói:

```txt
Người tham gia có thể có cơ hội nhận phần thưởng hoặc thu nhập khi tạo giá trị thật, có bằng chứng thật và được xác nhận theo quy trình.
```

---

## 10. Quy tắc pháp lý cho thông tin pháp nhân

Không được public thông tin sau nếu chưa được Legal xác nhận từ hồ sơ gốc:

```txt
mã số doanh nghiệp
địa chỉ đăng ký
người đại diện pháp luật
tài khoản ngân hàng
cổ phần chào bán
giá cổ phần
số tiền cần huy động
điều khoản đầu tư
tỷ lệ sở hữu
hợp đồng mẫu
```

Nếu cần nhắc pháp nhân, dùng cấu trúc tạm:

```txt
Chủ thể pháp lý dự kiến/đang được đối chiếu: Công ty Cổ phần Đầu tư Việt Úc Toàn Cầu. Thông tin chi tiết chỉ được hiển thị sau khi đối chiếu với hồ sơ pháp lý chính thức và được phê duyệt để công bố.
```

---

## 11. Legal gate trước khi deploy trang đầu tư

Trước khi deploy `dautu.muonnoi.org`, phải tick đủ:

```txt
[ ] Có legal owner phê duyệt nội dung
[ ] Có xác nhận pháp nhân từ hồ sơ gốc
[ ] Có xác nhận không phải public offering
[ ] Có disclaimer đặt trên hero hoặc trước form đăng ký
[ ] Không có ROI, cam kết, hoàn vốn, định giá tương lai
[ ] Không có nút “mua cổ phần” hoặc “chuyển tiền ngay”
[ ] Form chỉ là “đăng ký quan tâm”
[ ] Hồ sơ chi tiết gated/private
[ ] Có KYC/suitability workflow
[ ] Có data retention policy cho lead đầu tư
[ ] Có audit log cho tài liệu gửi nhà đầu tư
```

---

## 12. Final lock

Trang public của Muôn Nơi phải là lời mời xây giá trị thật.

Trang đầu tư của Muôn Nơi phải là cổng lọc quan tâm hợp pháp, không phải trang bán cổ phần công khai.

Mọi từ trên website phải bảo vệ niềm tin của hệ trước khi tạo chuyển đổi.
