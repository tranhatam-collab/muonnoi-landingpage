# MUÔN NƠI · PUBLIC SITE MASTER DEV HANDOFF 2026
**Scope:** `muonnoi.org` public shell + content update + Life Quest OS + trust narrative  
**Ngày:** 2026-05-11  
**Trạng thái:** Ready for DEV / Content / Design  
**Nguyên tắc:** Giữ những gì đang có, chỉ thêm và làm sâu hơn

---

## 1. Vai trò của trang chủ

Trang chủ `muonnoi.org` không phải nơi quảng cáo. Trang chủ là lời mời tham gia một cách sống khác: một internet khác, một hệ điều hành đời sống khác, một hệ thống nơi con người sống thật, học thật, làm thật và tạo giá trị thật.

Trang chủ phải trả lời được 7 câu hỏi trong 15 giây đầu:

1. Muôn Nơi là gì?
2. Vì sao nó khác mạng xã hội cũ?
3. Người dùng được gì?
4. Hệ sinh thái có những lớp nào?
5. Life Quest OS là gì?
6. Niềm tin và bảo mật được giữ như thế nào?
7. Người dùng, đối tác, host, nhà đầu tư nên đi tiếp ở đâu?

---

## 2. Định vị public cuối cùng

### H1

Tự Do Tuyệt Đối Từ Bên Trong  
Trách Nhiệm Rõ Ràng Trong Đời Sống Muôn Nơi.

### Subheading

Muôn Nơi là hạ tầng số cho đời sống thật — nơi con người sống, học, làm, đi, chăm sóc gia đình, sáng tạo, đóng góp cộng đồng và chia sẻ giá trị thật.

Giai đoạn đầu tập trung social-first: sạch, bảo mật, dễ dùng và có trách nhiệm. Khi nền tảng ổn định, hệ sinh thái mở rộng theo mô-đun để mỗi vùng đời sống có không gian riêng nhưng vẫn liên kết với cùng một trung tâm tin cậy.

### CTA chính

```txt
Vào ứng dụng             → https://app.muonnoi.org/
Xem hệ sinh thái         → /ecosystem/
Tham gia Quests          → /quests/
Xem dự án                → https://duan.muonnoi.org/
Tìm hiểu đầu tư          → https://dautu.muonnoi.org/
```

---

## 3. Homepage section order bắt buộc

```txt
1. Header
2. Hero
3. Three locks
4. Life Quest OS
5. Ecosystem modules
6. Navigation cards
7. Pilot callout
8. Principles
9. Partner/investor bridge
10. Final CTA
11. Footer
```

---

## 4. Section 3 · Three Locks

### Lock 1 · Tự do từ bên trong

Tự do thật không phải là vô trách nhiệm. Muôn Nơi thiết kế để con người được tự do nhưng vẫn có chuẩn, có giới hạn, có bảo mật và có trách nhiệm với cộng đồng.

### Lock 2 · Social-first

Muôn Nơi bắt đầu từ social core: đăng ký, hồ sơ, feed, thảo luận, xác minh, cam kết, khiếu nại và cộng đồng thật.

### Lock 3 · Module-first

Không xây một siêu ứng dụng nặng nề. Muôn Nơi mở rộng bằng các mô-đun riêng: học tập, làm việc, du lịch, gia đình, sức khỏe, sáng tạo, cộng đồng, đầu tư và nhà chung.

---

## 5. Section 4 · Life Quest OS

### H2

Hệ nhiệm vụ đời sống — chơi để sống tốt hơn.

### Body

Trên hạ tầng Muôn Nơi, chúng tôi xây một lớp mới: những hệ nhiệm vụ đời sống nơi con người học, đi, làm, chăm sóc sức khỏe, gắn kết gia đình, sáng tạo và đóng góp cộng đồng.

Mỗi nhiệm vụ có bằng chứng thật. Mỗi hành động có giá trị thật. Mỗi đóng góp có thể trở thành một phần trong hồ sơ tín nhiệm của người tham gia.

Đây không phải game để giữ người trong màn hình. Đây là nhiệm vụ đời sống để đưa người ra thế giới thật.

### Seven cards

```txt
Đường Muôn Nơi       dulich.muonnoi.org       Mỗi điểm đến là một thử thách.
Học Đời              hoctap.muonnoi.org       Mỗi ngày học một kỹ năng đời.
Family Mission       family.muonnoi.org       Gia đình cùng lớn lên.
Một Ngày Khỏe        suckhoe.muonnoi.org      Mỗi ngày một hành động nhỏ.
Việc Có Lý           lamviec.muonnoi.org      Mỗi việc nhỏ xây uy tín thật.
Vườn Sáng Tạo        sangtao.muonnoi.org      Mỗi ngày tạo một thứ nhỏ.
Cồng                 congdong.muonnoi.org     Mỗi tuần một việc tốt.
```

---

## 6. Section 5 · Ecosystem modules

### Module list

```txt
Public Shell          muonnoi.org
Social Core           app.muonnoi.org
AI Social             ai.muonnoi.org
Docs                  docs.muonnoi.org
Family                family.muonnoi.org
Nhà Chung             nhachung.muonnoi.org
Làm Việc              lamviec.muonnoi.org
Học Tập               hoctap.muonnoi.org
Du Lịch               dulich.muonnoi.org
Dự Án                 duan.muonnoi.org
Đầu Tư                dautu.muonnoi.org
Verify                verify.muonnoi.org
Trust                 trust.muonnoi.org
```

### Copy

Muôn Nơi không phát triển thành một khối nặng. Hệ được tổ chức thành các mô-đun, mỗi mô-đun phục vụ một phần đời sống thật. Mọi mô-đun đều quay về cùng một lõi: danh tính, niềm tin, bằng chứng, bảo mật và giá trị thật.

---

## 7. Section 7 · Principles

### Six principles

```txt
Không tracking pixel
Không feed gây nghiện
Link bền là tài sản
Bằng chứng là gốc
Dữ liệu tối thiểu
Doanh thu sạch
```

### Principle copy

Muôn Nơi không xây hệ bằng cách khai thác sự chú ý. Muôn Nơi xây bằng giá trị có thể kiểm chứng. Người dùng không phải sản phẩm. Dữ liệu không phải hàng hóa. Cộng đồng không phải nguồn traffic. Mỗi hành động có giá trị phải có bằng chứng, có trách nhiệm và có đường dẫn bền.

---

## 8. Section 9 · Partner/investor bridge

### H2

Cùng xây hạ tầng cho đời sống thật.

### Body

Muôn Nơi mở cửa cho cá nhân, tổ chức, doanh nghiệp, cộng đồng và quỹ đầu tư có cùng tầm nhìn: xây dựng một hệ sinh thái công nghệ phục vụ con người, gia đình, việc làm, học tập, du lịch, sức khỏe, nhà chung, cộng đồng và các dự án có giá trị thật.

Các cơ hội đồng hành được mở theo từng lớp: đối tác vận hành, Local Host, mentor, city partner, technology partner, education partner, community partner và nhà đầu tư chiến lược.

Mọi thông tin đầu tư chi tiết được xử lý qua cổng riêng, có xác minh phù hợp và tuân thủ quy trình pháp lý áp dụng.

### CTA

```txt
Xem dự án             → https://duan.muonnoi.org/
Tìm hiểu đầu tư       → https://dautu.muonnoi.org/
Trở thành đối tác     → /partners/
Trở thành Local Host  → /host/
```

---

## 9. Footer mở rộng

```txt
SẢN PHẨM
- Ứng dụng
- AI Muôn Nơi
- Quests
- Làm việc
- Hướng dẫn
- Bảo mật
- Trạng thái

QUESTS
- Đường Muôn Nơi
- Học Đời
- Family Mission
- Một Ngày Khỏe
- Việc Có Lý
- Vườn Sáng Tạo
- Cồng

HỆ SINH THÁI
- Nhà Chung
- Dự Án
- Đầu Tư
- Verify
- Trust
- Docs

CÔNG TY
- Câu chuyện
- Manifesto
- Đối tác
- Press
- Nghề nghiệp

PHÁP LÝ
- Privacy
- Terms
- Cookies
- DMCA
```

---

## 10. Pages phải tạo/cập nhật

### Tạo mới

```txt
apps/web/public/about/index.html
apps/web/public/manifesto/index.html
apps/web/public/quests/index.html
apps/web/public/quests/dulich/index.html
apps/web/public/host/index.html
apps/web/public/partners/index.html
apps/web/public/press/index.html
```

### Cập nhật

```txt
apps/web/public/index.html
apps/web/public/ecosystem/index.html
apps/web/public/roadmap/index.html
apps/web/public/security/index.html
apps/web/public/guide/index.html
apps/web/public/assets/ui.css
apps/web/public/assets/ui.js
apps/web/public/_headers
apps/web/public/_redirects
apps/web/public/sitemap.xml
apps/web/public/robots.txt
apps/web/public/manifest.json
```

---

## 11. Definition of Done public site

```txt
[ ] Trang chủ có Life Quest OS section
[ ] Trang chủ có bridge sang duan và dautu
[ ] Không dùng câu hứa hẹn tài chính
[ ] Header có Quests / Manifesto / Ecosystem / Roadmap / Security / Guide
[ ] Footer 5 cột đầy đủ
[ ] Theme toggle hoạt động
[ ] VI/EN toggle không vỡ layout
[ ] Mobile menu hoạt động
[ ] Không link chết
[ ] Sitemap có tất cả pages mới
[ ] Robots không chặn public pages
[ ] CSP không làm vỡ assets
[ ] Lighthouse mobile pass cơ bản
```
