# MUÔN NƠI · DEV HANDOFF PACKAGE 2026
**Gói giao DEV + Content + Legal Review**  
**Ngày:** 2026-05-11  
**Trạng thái:** Ready for internal DEV handoff · Legal review required before public investment pages  
**Ngôn ngữ:** Tiếng Việt chính · English secondary  
**Owner:** Trần Hà Tâm / Muôn Nơi

---

## 0. Mục đích gói file

Gói này gom toàn bộ định hướng công bố mới của `muonnoi.org`, các trang dự án, trang đầu tư, kế hoạch file DEV phải tạo/cập nhật, và một file khóa chuẩn ngôn ngữ/pháp lý để team code không viết lệch hướng.

Gói này được tạo để:

1. DEV biết chính xác phải làm file nào, ở đâu, thứ tự nào.
2. Content biết giọng văn nào được dùng, từ nào cấm, từ nào cần tránh.
3. Design biết cấu trúc page, CTA, trạng thái, mô-đun, navigation.
4. Legal biết phần nào phải duyệt trước khi public, đặc biệt là `dautu.muonnoi.org` và các trang kêu gọi đồng hành.
5. Founder có một bản thống nhất để giao team triển khai không bị vá rời rạc.

---

## 1. Các file trong gói

```txt
README_INDEX_MUONNOI_DEV_PACKAGE_2026.md
MUONNOI_PUBLIC_SITE_MASTER_DEV_HANDOFF_2026.md
MUONNOI_INVESTMENT_AND_PROJECT_PORTAL_DEV_HANDOFF_2026.md
MUONNOI_LANGUAGE_AND_LEGAL_LOCK_2026.md
MUONNOI_DEV_FILE_TASK_MATRIX_2026.md
```

---

## 2. Cách dùng nhanh

### DEV đọc trước

1. `MUONNOI_LANGUAGE_AND_LEGAL_LOCK_2026.md`
2. `MUONNOI_DEV_FILE_TASK_MATRIX_2026.md`
3. `MUONNOI_PUBLIC_SITE_MASTER_DEV_HANDOFF_2026.md`
4. `MUONNOI_INVESTMENT_AND_PROJECT_PORTAL_DEV_HANDOFF_2026.md`

### Content đọc trước

1. `MUONNOI_LANGUAGE_AND_LEGAL_LOCK_2026.md`
2. `MUONNOI_PUBLIC_SITE_MASTER_DEV_HANDOFF_2026.md`
3. `MUONNOI_INVESTMENT_AND_PROJECT_PORTAL_DEV_HANDOFF_2026.md`

### Legal đọc trước

1. `MUONNOI_LANGUAGE_AND_LEGAL_LOCK_2026.md`
2. `MUONNOI_INVESTMENT_AND_PROJECT_PORTAL_DEV_HANDOFF_2026.md`
3. Các hồ sơ pháp nhân nội bộ tại `pay.iai.one` hoặc thư mục pháp lý chính thức.

---

## 3. Nguyên tắc khóa

Không public bất kỳ nội dung nào về đầu tư nếu chưa qua checklist pháp lý trong `MUONNOI_LANGUAGE_AND_LEGAL_LOCK_2026.md`.

Không ghi hứa hẹn lợi nhuận, hoàn vốn, cam kết tăng trưởng, định giá tương lai, hoặc câu chữ có thể bị hiểu là chào bán chứng khoán công khai.

Không tự điền thông tin pháp nhân, mã số doanh nghiệp, đại diện pháp luật, tài khoản nhận tiền, giấy tờ pháp lý nếu chưa được đối chiếu từ hồ sơ gốc.

Public site `muonnoi.org` chỉ nói về giá trị thật, hạ tầng thật, con người thật, lộ trình xây dựng, sản phẩm, hệ sinh thái, nhiệm vụ đời sống và lời mời đồng hành.

Trang đầu tư `dautu.muonnoi.org` chỉ là cổng đăng ký quan tâm, lọc phù hợp và chuyển vào quy trình gated/private, không phải trang chào bán công khai.
