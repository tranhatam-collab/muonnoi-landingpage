# MUÔN NƠI · INVESTMENT AND PROJECT PORTAL DEV HANDOFF 2026
**Scope:** `dautu.muonnoi.org` + `duan.muonnoi.org` + public bridge pages  
**Ngày:** 2026-05-11  
**Trạng thái:** Draft for DEV · Legal approval required before public launch

---

## 1. Mục tiêu

Xây hai cổng riêng nhưng liên kết chặt:

```txt
duan.muonnoi.org    → danh mục dự án, nhu cầu đồng hành, trạng thái triển khai
dautu.muonnoi.org   → cổng đăng ký quan tâm đầu tư / hợp tác, gated investor flow
```

Hai trang này không phải nơi bán cổ phần công khai. Đây là nơi công bố hệ sinh thái, dự án, nhu cầu đồng hành và dẫn người phù hợp vào quy trình riêng.

---

## 2. Nguyên tắc pháp lý quan trọng

Trang `dautu.muonnoi.org` là trang công khai, vì vậy không được trình bày như một lời chào bán cổ phần/chứng khoán công khai nếu chưa có hồ sơ và tư vấn pháp lý đầy đủ.

Luật Doanh nghiệp 2020, Điều 125 về chào bán cổ phần riêng lẻ của công ty cổ phần không đại chúng quy định việc chào bán riêng lẻ không được thực hiện qua phương tiện thông tin đại chúng và chỉ áp dụng cho dưới 100 nhà đầu tư, không kể nhà đầu tư chứng khoán chuyên nghiệp, hoặc chỉ cho nhà đầu tư chứng khoán chuyên nghiệp.

Luật Chứng khoán 2019 định nghĩa chào bán chứng khoán ra công chúng có thể bao gồm chào bán qua phương tiện thông tin đại chúng, chào bán cho từ 100 nhà đầu tư trở lên không kể nhà đầu tư chứng khoán chuyên nghiệp, hoặc chào bán cho số lượng nhà đầu tư không xác định.

Vì vậy: `dautu.muonnoi.org` chỉ nên là cổng đăng ký quan tâm và lọc phù hợp; tài liệu chi tiết, điều khoản, hồ sơ pháp lý, mô hình đầu tư, cổ phần, tỷ lệ, số tiền, hợp đồng phải nằm trong private gated flow.

---

## 3. `duan.muonnoi.org` — vai trò

`duan.muonnoi.org` là nơi công bố danh mục dự án trong toàn hệ Muôn Nơi.

Không chỉ là dự án nhà đất. Gồm:

```txt
công nghệ
giáo dục
việc làm
du lịch
nghỉ dưỡng
gia đình
trẻ em
người già
sức khỏe
nhà chung
cộng đồng
đầu tư phát triển dự án thật
```

### H1

Dự Án Muôn Nơi  
Nơi các giá trị thật được xây thành hệ thống.

### Intro

Mỗi dự án trong Muôn Nơi phải phục vụ một phần của đời sống thật: nơi ở, học tập, việc làm, sức khỏe, gia đình, du lịch, sáng tạo, cộng đồng hoặc công nghệ.

Chúng tôi không phát triển dự án rời rạc. Mỗi dự án phải liên kết với hệ sinh thái chung: có người dùng thật, nhu cầu thật, mô hình vận hành rõ, bằng chứng thực thi và khả năng tạo giá trị dài hạn.

---

## 4. Nhóm dự án trên `duan.muonnoi.org`

### 4.1 Công nghệ

```txt
AI social
workflow platform
identity/trust layer
proof/receipt system
verified profile
Life Quest OS
```

### 4.2 Giáo dục

```txt
Học Đời
Lớp X
kỹ năng sống
kỹ năng AI
đào tạo nghề
chương trình trẻ em / người lớn
```

### 4.3 Việc làm

```txt
Work Quest
microtask
dự án cộng tác
portfolio có proof
verified freelancer
cộng đồng làm việc xuyên biên giới
```

### 4.4 Du lịch và trải nghiệm

```txt
Đường Muôn Nơi
Local Host
City Quests
du lịch học tập
du lịch gia đình
trải nghiệm địa phương
```

### 4.5 Gia đình

```txt
Family Mission
giáo dục con cái
chăm sóc cha mẹ
tài chính gia đình
ký ức gia đình
không gian gia đình số an toàn
```

### 4.6 Sức khỏe và đời sống

```txt
Một Ngày Khỏe
thói quen sống
cộng đồng thể chất
wellness education
kết nối gia đình trong chăm sóc sức khỏe
```

### 4.7 Nhà chung và cộng đồng sống

```txt
nhachung.muonnoi.org
không gian sống chung
farmstay
co-living
cộng đồng có chuẩn vận hành rõ
```

### 4.8 Người già và trẻ em

```txt
chăm sóc người lớn tuổi
học tập cho trẻ
bảo vệ trẻ em
kết nối thế hệ
gia đình đa thế hệ
```

### 4.9 Đầu tư cộng đồng

```txt
dự án cần vốn
dự án cần đối tác
dự án cần chuyên gia
dự án cần người vận hành
dự án cần cộng đồng tham gia
```

---

## 5. Project card schema

Mỗi project card cần dữ liệu:

```json
{
  "id": "project_slug",
  "name": "Tên dự án",
  "domain": "technology | education | work | travel | family | health | living | community | investment",
  "stage": "Planned | In Progress | Active Pilot | Ready for Partner | Ready for Investment Review | Legal Review Required | Archived",
  "location": "Đà Lạt / Việt Nam / Global",
  "summary": "Mô tả ngắn",
  "value_created": "Giá trị xã hội / kinh tế / cộng đồng",
  "needs": ["capital", "partner", "operator", "expert", "community"],
  "legal_status": "public | gated | legal_review_required",
  "cta": "View detail | Register interest | Partner with us"
}
```

---

## 6. Project status lock

Chỉ dùng các trạng thái sau:

```txt
Planned
In Progress
In Review
Ready for Partner
Ready for Investment Review
Legal Review Required
Active Pilot
Closed / Archived
```

Không dùng:

```txt
siêu lợi nhuận
đảm bảo thắng
cam kết tăng trưởng
đã chắc chắn thành công
```

---

## 7. `dautu.muonnoi.org` — vai trò

`dautu.muonnoi.org` là cổng đầu tư/đồng hành có kiểm soát pháp lý.

### H1

Đầu Tư Muôn Nơi  
Đồng hành xây hạ tầng cho đời sống thật.

### Intro

Muôn Nơi mời các cá nhân, tổ chức, doanh nghiệp và quỹ đầu tư cùng đồng hành trong một hệ sinh thái đang được xây dựng từ Việt Nam, hướng đến thị trường trong nước và quốc tế.

Đây không phải một dự án đơn lẻ. Đây là một chuỗi hạ tầng gồm công nghệ, social core, AI, workflow, giáo dục, việc làm, du lịch, gia đình, nhà chung, sức khỏe, cộng đồng và đầu tư phát triển dự án thật.

Các cơ hội đầu tư, hợp tác và đồng hành sẽ được công bố theo từng giai đoạn, theo đúng điều kiện pháp lý và mức độ phù hợp của từng nhà đầu tư.

---

## 8. Chủ thể pháp lý

### Không tự điền nếu chưa có hồ sơ gốc

Trang có thể đặt block:

```txt
Chủ thể pháp lý đang được đối chiếu từ hồ sơ nội bộ:
Công ty Cổ phần Đầu tư Việt Úc Toàn Cầu.

Thông tin pháp nhân chi tiết, giấy tờ đăng ký, người đại diện, tài khoản nhận vốn hoặc hồ sơ đầu tư chỉ được công bố hoặc cung cấp sau khi đối chiếu với hồ sơ pháp lý chính thức và được phê duyệt để chia sẻ.
```

Nếu legal đã xác nhận, mới được hiển thị:

```txt
Tên pháp nhân
Mã số doanh nghiệp
Địa chỉ đăng ký
Người đại diện pháp luật
Tài liệu pháp lý được phép công bố
```

---

## 9. Các hướng đồng hành đầu tư

### 9.1 Đầu tư công nghệ

Dành cho nhà đầu tư quan tâm đến AI, social platform, workflow, identity, trust layer, dữ liệu bằng chứng và hạ tầng số.

### 9.2 Đầu tư dự án đời sống

Dành cho nhà đầu tư quan tâm đến nhà chung, du lịch, giáo dục, sức khỏe, gia đình, người già, trẻ em, cộng đồng sống và không gian trải nghiệm.

### 9.3 Đầu tư địa phương

Dành cho đối tác muốn cùng mở một city pilot: Đà Lạt, Sài Gòn, Hà Nội, Hội An, Bangkok, Singapore, Tokyo, Paris, New York.

### 9.4 Đầu tư vận hành

Dành cho doanh nghiệp hoặc cá nhân có năng lực vận hành host, cộng đồng, đào tạo, sự kiện, local services, city chapters.

### 9.5 Đầu tư chiến lược

Dành cho quỹ, tổ chức hoặc doanh nghiệp muốn đồng hành dài hạn với hạ tầng Muôn Nơi ở cấp hệ sinh thái.

---

## 10. Value narrative 1–5 năm

### Sau 1 năm

```txt
Social core ổn định
Life Quest OS có pilot thực tế
Đà Lạt và một số thành phố đầu tiên có dữ liệu vận hành
hệ thống host, quest, proof, profile, trust bước đầu hình thành
cộng đồng người dùng, host, mentor, contributor có hoạt động thật
```

### Sau 2 năm

```txt
nhiều mô-đun đời sống đi vào vận hành
hệ du lịch, học tập, gia đình, việc làm, sức khỏe có sản phẩm rõ
hệ thống dự án và đầu tư có dữ liệu kiểm chứng hơn
các đối tác, doanh nghiệp, tổ chức tham gia qua cổng riêng
tài sản công nghệ và tài sản cộng đồng bắt đầu hình thành
```

### Sau 3–5 năm

```txt
Muôn Nơi có thể trở thành hạ tầng đời sống số từ Việt Nam mở ra quốc tế
city chapters, local hosts, learning circles, work quests, family missions, community quests vận hành ở nhiều thị trường
cơ hội doanh thu đến từ sản phẩm thật, dịch vụ thật, giáo dục, du lịch, cộng đồng, marketplace, đối tác và hạ tầng
```

Không ghi con số lợi nhuận hoặc định giá nếu chưa có model audited/private deck.

---

## 11. Investor flow

```txt
Public page
→ Register interest
→ Suitability questions
→ KYC / entity type check
→ Legal disclaimer acceptance
→ Private dossier access
→ Meeting request
→ NDA if required
→ Project-specific data room
→ Legal documentation
→ Board/shareholder/legal process
```

---

## 12. Form fields for `dautu.muonnoi.org/interest`

```txt
Họ tên / Full name
Email
Phone
Country
Investor type: individual / company / fund / NGO / strategic partner
Area of interest: technology / travel / education / family / health / living / community / strategic
Expected role: investor / operator / advisor / partner
Approximate interest range: optional, gated, can be hidden until legal approves
Experience / background
How did you hear about Muôn Nơi?
Checkbox: Tôi hiểu đây không phải lời chào bán chứng khoán công khai
Checkbox: Tôi hiểu không có cam kết lợi nhuận hoặc hoàn vốn
Checkbox: Tôi đồng ý được liên hệ để xác minh phù hợp
```

---

## 13. Disclaimer block for page and form

Thông tin trên trang này chỉ nhằm giới thiệu định hướng, hệ sinh thái và cơ hội đồng hành. Đây không phải lời chào bán chứng khoán, không phải cam kết lợi nhuận, không phải bảo đảm hoàn vốn và không thay thế tư vấn pháp lý, tài chính hoặc đầu tư độc lập.

Nhà đầu tư cần tự đánh giá rủi ro, năng lực tài chính và mức độ phù hợp trước khi tham gia. Các hồ sơ chi tiết chỉ được cung cấp trong cổng đầu tư riêng sau khi hoàn tất xác minh phù hợp và tuân thủ quy trình pháp lý áp dụng.

---

## 14. Pages/files to create

### Public path inside `apps/web/public` first

```txt
apps/web/public/invest/index.html
apps/web/public/invest/legal/index.html
apps/web/public/invest/interest/index.html
apps/web/public/projects/index.html
apps/web/public/projects/technology/index.html
apps/web/public/projects/living/index.html
apps/web/public/projects/education/index.html
apps/web/public/projects/travel/index.html
apps/web/public/projects/family/index.html
apps/web/public/projects/health/index.html
apps/web/public/projects/community/index.html
```

### Later subdomain apps

```txt
apps/dautu/public/index.html
apps/duan/public/index.html
```

---

## 15. API/data model later

```txt
GET  /api/projects
GET  /api/projects/:id
POST /api/investment-interest
GET  /api/investment-interest/:id/admin
POST /api/investment-interest/:id/status
POST /api/investment-interest/:id/notes
POST /api/investment-interest/:id/doc-access
```

D1 tables:

```sql
project_registry
project_categories
project_updates
project_documents
investment_interest
investment_interest_status_log
investor_profiles
investor_document_access
legal_review_log
audit_log
```

---

## 16. Definition of Done

```txt
[ ] `duan` page has project categories and no financial promises
[ ] `dautu` page has legal disclaimer above form
[ ] No investment terms public without legal approval
[ ] No ROI / return / guarantee language
[ ] Legal entity fields are placeholders until verified
[ ] Interest form logs consent checkboxes
[ ] Admin can export leads securely later
[ ] Sitemap includes invest/projects pages only after legal approval
[ ] Robots can temporarily noindex invest pages until legal approval
```
