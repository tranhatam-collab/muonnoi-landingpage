# MUÔN NƠI · DEV FILE TASK MATRIX 2026
**Scope:** Public site + Life Quest OS + Project/Investment Portals  
**Ngày:** 2026-05-11

---

## 1. P0 — Làm ngay trong tuần 1

| Priority | File | Action | Owner | Notes |
|---|---|---|---|---|
| P0 | `apps/web/public/index.html` | Update | Frontend | Add Life Quest OS, principles, partner/investor bridge |
| P0 | `apps/web/public/manifesto/index.html` | Create | Frontend/Content | Full manifesto VI first, EN later |
| P0 | `apps/web/public/about/index.html` | Create | Frontend/Content | Story + founder + current layers |
| P0 | `apps/web/public/quests/index.html` | Create | Frontend/Content | Life Quest OS overview |
| P0 | `apps/web/public/quests/dulich/index.html` | Create | Frontend/Content | Đường Muôn Nơi pilot page |
| P0 | `apps/web/public/host/index.html` | Create | Frontend/Content | Local Host landing |
| P0 | `apps/web/public/ecosystem/index.html` | Update | Frontend | 8 layers infrastructure |
| P0 | `apps/web/public/roadmap/index.html` | Update | Frontend | 6 phases + pilot cities |
| P0 | `apps/web/public/assets/ui.css` | Update | Frontend | Add quest-card, principle-card, pilot-callout, legal-note |
| P0 | `apps/web/public/assets/ui.js` | Update | Frontend | Theme/lang/menu/accordion stability |
| P0 | `apps/web/public/_redirects` | Update | Frontend | New routes |
| P0 | `apps/web/public/sitemap.xml` | Update | SEO | Add public routes after legal check |

---

## 2. P1 — Tuần 2

| Priority | File | Action | Owner | Notes |
|---|---|---|---|---|
| P1 | `apps/web/public/quests/hoctap/index.html` | Create | Frontend/Content | Học Đời |
| P1 | `apps/web/public/quests/family/index.html` | Create | Frontend/Content | Family Mission |
| P1 | `apps/web/public/partners/index.html` | Create | Frontend/Content | Partners page |
| P1 | `apps/web/public/press/index.html` | Create | Frontend/Content | Press kit |
| P1 | `apps/web/public/security/index.html` | Update | Frontend/Content | Proof security, host safety, child/family safety |
| P1 | `apps/web/public/guide/index.html` | Update | Frontend/Content | Join quests, submit proof, legal earning language |
| P1 | `apps/web/public/invest/index.html` | Create draft | Frontend/Legal | Keep noindex until legal approval |
| P1 | `apps/web/public/projects/index.html` | Create draft | Frontend/Product | Project registry shell |

---

## 3. P2 — Tuần 3

| Priority | File | Action | Owner | Notes |
|---|---|---|---|---|
| P2 | `apps/web/public/quests/suckhoe/index.html` | Create | Frontend/Content | Một Ngày Khỏe |
| P2 | `apps/web/public/quests/lamviec/index.html` | Create | Frontend/Content | Việc Có Lý |
| P2 | `apps/web/public/quests/sangtao/index.html` | Create | Frontend/Content | Vườn Sáng Tạo |
| P2 | `apps/web/public/quests/congdong/index.html` | Create | Frontend/Content | Cồng |
| P2 | `apps/web/public/projects/technology/index.html` | Create | Frontend/Product | Category page |
| P2 | `apps/web/public/projects/living/index.html` | Create | Frontend/Product | Category page |
| P2 | `apps/web/public/projects/education/index.html` | Create | Frontend/Product | Category page |
| P2 | `apps/web/public/projects/travel/index.html` | Create | Frontend/Product | Category page |
| P2 | `apps/web/public/projects/family/index.html` | Create | Frontend/Product | Category page |
| P2 | `apps/web/public/projects/health/index.html` | Create | Frontend/Product | Category page |
| P2 | `apps/web/public/projects/community/index.html` | Create | Frontend/Product | Category page |

---

## 4. P3 — Tuần 4

| Priority | File | Action | Owner | Notes |
|---|---|---|---|---|
| P3 | `apps/dulich/public/index.html` | Create | Frontend | Subdomain live app shell |
| P3 | `apps/dautu/public/index.html` | Create only after legal | Frontend/Legal | No public launch before approval |
| P3 | `apps/duan/public/index.html` | Create | Frontend/Product | Registry subdomain |
| P3 | `apps/web/public/en/*` | Create | Content | English mirrors |
| P3 | Press/OG assets | Create | Design | OG images, brand assets |

---

## 5. Shared component requirements

### CSS components to add

```txt
.mn-questCard
.mn-principleCard
.mn-pilotCallout
.mn-hostCard
.mn-proofCard
.mn-legalNote
.mn-disclaimerBox
.mn-projectCard
.mn-statusPill
.mn-investorForm
.mn-riskNotice
```

### JS behavior to keep stable

```txt
Theme toggle
VI/EN toggle
Mobile menu
Accordion for FAQ / long legal sections
Copy link button if needed
No inline JS that violates CSP
```

---

## 6. Cloudflare Pages requirements

For `apps/web/public` deployment:

```txt
Root directory: apps/web
Build command: empty
Build output: public
```

---

## 7. Final test checklist

```txt
[ ] `/` loads with CSS
[ ] `/quests/` loads
[ ] `/quests/dulich/` loads
[ ] `/host/` loads
[ ] `/partners/` loads
[ ] `/press/` loads
[ ] `/invest/` is noindex or gated until legal approval
[ ] `/projects/` loads
[ ] Theme toggle works
[ ] Language toggle does not break page
[ ] Mobile menu works
[ ] CSP does not block CSS/JS/assets
[ ] No dead links in header/footer
[ ] Lighthouse mobile acceptable
[ ] No prohibited investment language
```
