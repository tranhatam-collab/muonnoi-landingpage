# MUONNOI_RELEASE_RUNBOOK_2026-05-11

**File:** `qa/release-gates/MUONNOI_RELEASE_RUNBOOK_2026-05-11.md`  
**Status:** Locked for mobile release operations  
**Scope:** Internal alpha, beta, RC, production release runbook for iOS + Android  
**Audience:** Product, Mobile, API, Platform, QA, Support  
**Updated:** 2026-05-11

---

## 1. Mục tiêu của file này

File này khóa cách Muôn Nơi phát hành build mobile:
- ai quyết định release
- release theo các giai đoạn nào
- gate nào phải qua
- rollback khi nào
- hotfix đi ra sao
- incident xử lý thế nào trong 24 giờ đầu sau phát hành

Mục tiêu:
- không release theo cảm giác
- không để lỗi production “mới phát hiện khi user gặp”
- không có ai hiểu sai trách nhiệm khi có sự cố

---

## 2. Mô hình release

## 2.1. Các lane phát hành
1. Internal dev build
2. Internal QA build
3. Alpha
4. Beta / closed test
5. Release Candidate
6. Production

Không nhảy thẳng từ internal lên production.

## 2.2. Kênh phân phối
- iOS: TestFlight internal / external / App Store
- Android: internal app sharing / closed testing / production

---

## 3. Vai trò và trách nhiệm

## 3.1. Release owner
Thường là Product hoặc Mobile lead.
Chịu trách nhiệm:
- tổng hợp readiness
- xin go/no-go
- công bố release note nội bộ
- xác nhận rollback trigger

## 3.2. Mobile lead
- xác nhận build reproducible
- xác nhận version / build number
- xác nhận feature flags
- xác nhận signing

## 3.3. API lead
- xác nhận backend compatibility
- xác nhận no breaking change
- xác nhận rollout window
- xác nhận monitoring active

## 3.4. QA lead
- xác nhận gates passed
- xác nhận smoke/regression result
- xác nhận known issues documented

## 3.5. Support / Ops
- xác nhận support inbox live
- xác nhận FAQ / canned responses
- xác nhận incident contact tree

---

## 4. Release stages and criteria

## 4.1. Internal dev build
Goal:
- compile
- install
- basic navigation smoke

Must pass:
- app boots
- auth shell reachable
- no fatal crash in first 5 min
- environment config correct

## 4.2. Internal QA build
Goal:
- functional smoke
- early regression
- API handshake

Must pass:
- login
- logout
- home load
- quest list
- profile
- settings
- report flow entry
- offline fallback basics

## 4.3. Alpha
Audience:
- founder, core team, trusted internal users

Must pass:
- QA smoke passed
- known issues documented
- no blocker in core flows
- analytics/crash signals visible if enabled

## 4.4. Beta / closed test
Audience:
- limited external testers

Must pass:
- crash threshold acceptable
- auth stable
- support path known
- release notes available
- feature flags reviewed

## 4.5. Release Candidate
Goal:
- exact build candidate for production

Must pass:
- all release gates green
- store assets ready
- policy URLs live
- final sign-off recorded

## 4.6. Production
Only after:
- founder/product approval
- QA approval
- mobile approval
- API approval
- support readiness confirmed

---

## 5. Go / No-go meeting

## 5.1. Required attendees
- Product / Release owner
- Mobile lead
- API lead
- QA lead
- Support/Ops representative

## 5.2. Agenda
1. version and build number
2. features enabled
3. known issues
4. metrics baseline
5. store readiness
6. rollback criteria
7. final go/no-go

## 5.3. Decision log
Must record:
- date/time
- attendees
- decision
- blockers accepted
- rollback owner

---

## 6. Versioning and build discipline

Each release must have:
- semantic app version
- monotonic build number
- branch/tag reference
- changelog
- environment target

No manual undocumented builds.

---

## 7. Feature flag rules

Feature flags must be reviewed before RC and production:
- list of enabled flags
- list of disabled flags
- remote kill-switch availability
- owner per flag

No hidden launch of unreviewed surfaces.

---

## 8. Rollback rules

## 8.1. Rollback triggers
Immediate rollback / halt rollout if:
- app cannot sign in for majority of users
- fatal crash on launch exceeds threshold
- broken navigation traps users
- proof submission corrupts data
- sensitive privacy/policy issue found
- notifications malfunction in harmful way
- backend incompatibility breaks core flow

## 8.2. Soft rollback / freeze rollout
- pause phased rollout
- disable risky flags
- publish hotfix plan
- inform support team

## 8.3. Who can trigger rollback
- release owner
- mobile lead
- API lead
- founder/product lead in major incident

---

## 9. Hotfix policy

Use hotfix lane only when:
- core flow broken
- data loss risk
- security/privacy issue
- store-blocking policy issue
- severe crash

Hotfix must still pass:
- targeted regression
- smoke on key devices
- sign-off from QA + owning engineer

---

## 10. Observability minimum

For each release, team must monitor:
- launch crash rate
- login success rate
- home load success rate
- quest detail load success rate
- proof draft save success rate
- API 5xx rate
- support ticket spike
- battery/network abnormal behavior reports if surfaced

If metrics are not available, release owner must explicitly note reduced observability risk.

---

## 11. First 24 hours protocol

## 11.1. T+0 to T+2h
- monitor crash
- monitor auth
- verify store listing correct
- verify deep links
- verify support mailbox

## 11.2. T+2h to T+8h
- inspect top user reports
- inspect API error rates
- inspect notification behavior
- check quest/proof flows

## 11.3. T+8h to T+24h
- summarize anomalies
- decide continue / pause / hotfix
- update known issues log

---

## 12. Support protocol

Support must have ready:
- login issue reply
- crash after update reply
- offline confusion reply
- notification permission reply
- report/complaint acknowledgement
- “known issue, fix in progress” reply

No production release without a staffed support owner.

---

## 13. Release checklist

Before release:
- [ ] build reproducible
- [ ] version/build number locked
- [ ] QA passed
- [ ] API compatible
- [ ] policy URLs live
- [ ] feature flags reviewed
- [ ] release notes ready
- [ ] support ready
- [ ] rollback plan ready
- [ ] go/no-go recorded

After release:
- [ ] smoke on production build
- [ ] metrics monitored
- [ ] first incident sweep
- [ ] support inbox checked
- [ ] release summary posted internally

---

## 14. Incident severity

## P0
- app unusable
- auth impossible
- serious privacy/security issue
- immediate rollback or hotfix

## P1
- major flow broken but workaround exists
- pause rollout or hotfix fast

## P2
- degraded non-core behavior
- document and fix next patch

## P3
- cosmetic or low-frequency edge case
- backlog

---

## 15. Communication rules

If there is an incident:
- one owner speaks internally
- support gets one source of truth
- do not invent timelines
- do not blame users
- do not say issue is fixed until verified

---

## 16. Release freeze rules

No release if:
- unresolved P0/P1 from prior build
- policy URLs missing
- support owner unavailable
- API rollout uncertain
- feature scope changed after RC without QA rerun

---

## 17. Chốt cuối

Muôn Nơi mobile không được phát hành như “đăng một bản build lên store”.  
Mỗi release phải được xem như một **cam kết vận hành**:

- build đúng
- product rõ
- support sẵn
- rollback có thật
- và người dùng không bị biến thành QA miễn phí.
