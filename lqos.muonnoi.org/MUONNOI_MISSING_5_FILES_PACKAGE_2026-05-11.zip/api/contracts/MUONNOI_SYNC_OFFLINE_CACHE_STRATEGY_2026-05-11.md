# MUONNOI_SYNC_OFFLINE_CACHE_STRATEGY_2026-05-11

**File:** `api/contracts/MUONNOI_SYNC_OFFLINE_CACHE_STRATEGY_2026-05-11.md`  
**Status:** Locked for Sprint 01 foundation  
**Scope:** Mobile read/write sync, cache strategy, retries, conflict handling, queue rules  
**Audience:** API, Mobile, Platform, QA  
**Updated:** 2026-05-11

---

## 1. Mục tiêu của file này

File này khóa nguyên tắc dữ liệu cho mobile app Muôn Nơi:
- dữ liệu nào được cache
- dữ liệu nào không được cache
- khi offline thì app làm gì
- khi resume network thì sync ra sao
- optimistic update được dùng ở đâu
- conflict được xử lý như thế nào

Mục tiêu:
- app không “giả online”
- không mất dữ liệu người dùng
- không tạo ảo giác thành công khi backend chưa xác nhận
- không làm người dùng phải nhập lại unnecessarily

---

## 2. Nguyên tắc tổng

1. **Network truth, local resilience.**  
   Server là nguồn sự thật cuối cùng. Cache local chỉ để tăng trải nghiệm và chống gián đoạn.

2. **Không giả thành công cho mutation nhạy cảm.**  
   Join quest, submit proof, trust/report actions không được hiển thị là thành công nếu backend chưa xác nhận, trừ khi flow được thiết kế rõ là queued.

3. **Read can be stale, write cannot be misleading.**

4. **Offline-first có chọn lọc, không cực đoan.**  
   Mục tiêu là dùng tốt khi mạng yếu, không phải biến app thành local-first phức tạp ngoài phạm vi Sprint 01.

---

## 3. Phân loại dữ liệu

## 3.1. Cache-safe read data
Có thể cache local và hiển thị khi offline:
- home feed snapshot
- quest catalog
- quest detail đã từng mở
- room list
- room detail đã từng mở
- profile snapshot
- settings snapshot
- legal/help static content
- app config flags non-sensitive

## 3.2. Sensitive / non-cache or restricted cache
Chỉ cache rất hạn chế hoặc không cache raw:
- auth tokens
- session secrets
- proof upload binaries khi chưa mã hóa/local secure store phù hợp
- trust decisions
- complaint submission payload nhạy cảm nếu chưa gửi
- moderation/internal notes
- one-time server challenges
- payment or legal gated artifacts

## 3.3. Queueable writes
Có thể lưu local pending và gửi lại sau:
- preference change
- draft proof text/meta
- media upload tasks as pending references
- save post/unsave-like actions if introduced later
- lightweight analytics/event envelopes if privacy policy allows

## 3.4. Non-queueable writes by default
Không được xác nhận offline:
- sign in / sign up completion
- verify submission final state
- complaint final submission unless policy approved
- joining paid/protected quest
- accepting legal terms requiring server receipt
- stateful actions that depend on quotas/capacity

---

## 4. Read strategy by surface

## 4.1. Home feed
Policy: **stale-while-revalidate**

- open screen
- show cached snapshot immediately if available
- fetch fresh in background
- if fresh succeeds, replace list and stamp updated_at
- if fresh fails, keep cached and show stale banner if age threshold exceeded

Recommended stale threshold:
- soft stale: 5 minutes
- hard stale banner: 30 minutes

## 4.2. Quest catalog
Policy: **cache-first with background refresh**

Quest catalog changes slower than notifications. Cached list is acceptable if timestamp displayed internally.

## 4.3. Quest detail
Policy: **cache-if-seen + fetch-on-open**

If the quest detail was previously loaded:
- show snapshot
- refetch detail
- if backend says quest unavailable/closed, update immediately

## 4.4. Notifications
Policy: **network-first, cached fallback**

Notifications are sensitive to recency.
- attempt network first
- if fail, show cached list with stale banner
- unread count must not pretend to be current if offline

## 4.5. Profile
Policy: **cache-first + on-focus refresh**

## 4.6. Settings
Policy: **local source of truth for preferences, server reconciliation where relevant**

---

## 5. Mutation strategy

## 5.1. Preference changes
Examples:
- language
- theme
- notification toggles

Policy:
- optimistic update allowed
- store local immediately
- enqueue server sync if needed
- if server rejects, keep local if preference is device-only, otherwise rollback and notify

## 5.2. Quest join
Policy:
- no fake success
- button enters submitting state
- success only after server ack
- if offline, show:
  - "Không thể tham gia khi đang offline"
  - optional save/remember action if product wants reminder

## 5.3. Proof submission
Policy:
- split into draft and final
- local draft always supported
- final submit requires server acknowledgement
- media can upload asynchronously once online
- draft must persist app restart

Recommended local states:
- draft_local
- queued_for_upload
- uploading
- uploaded_waiting_submit
- submit_requested
- submitted_pending_review
- submit_failed_retryable
- submit_failed_non_retryable

## 5.4. Complaint / report
Policy:
- save draft locally optional
- final submission should be online-only in Sprint 01
- never show complaint submitted if backend has not stored it

## 5.5. Mark notification read
Policy:
- optimistic local okay
- enqueue server sync
- if sync fails, do not aggressively revert in UI unless counts become misleading

---

## 6. Queue design

## 6.1. Local queue shape
Each queued action should store:
- local_action_id
- type
- payload reference
- created_at
- retry_count
- next_retry_at
- last_error_code
- last_error_message
- user_id/session scope
- dedupe_key if relevant

## 6.2. Queue processing triggers
- app foreground
- network regained
- manual retry
- background job if OS/platform allows and approved

## 6.3. Retry policy
Recommended:
- retry 1: 15 sec
- retry 2: 60 sec
- retry 3: 5 min
- retry 4: 15 min
- retry 5+: manual or daily gentle retry depending action type

No infinite hot loop retries.

---

## 7. Conflict handling

## 7.1. Read conflicts
Newest server response wins.

## 7.2. Draft conflicts
If a local draft and server draft differ:
- if server has newer `updated_at`, prompt merge/replace only for user-authored longform content
- for Sprint 01, local draft wins until final submission unless explicit server draft feature exists

## 7.3. Preference conflicts
Device-local preferences can remain local.
Account-level preferences use latest timestamp wins unless product defines priority.

## 7.4. Entity conflicts after optimistic UI
If user sees local optimistic state and server rejects:
- rollback
- surface reason if user-actionable
- preserve draft where possible
- never silently discard user-authored content

---

## 8. API contract requirements

Every write endpoint used by mobile should define:
- request id / idempotency support where relevant
- canonical success response shape
- retryable vs non-retryable error codes
- validation errors in machine-readable form
- server timestamp
- authoritative entity snapshot when mutation changes local cache

Suggested common response fields:
- `ok`
- `code`
- `message`
- `server_time`
- `data`
- `retryable`
- `field_errors`

---

## 9. Error taxonomy for sync

## 9.1. Retryable
- timeout
- temporary network unavailable
- 502 / 503 / 504
- transient upload transport failure

## 9.2. Not retryable without user change
- 400 validation
- 401 unauthorized until reauth
- 403 forbidden
- 404 entity unavailable
- 409 semantic conflict needing refresh
- 422 invalid payload
- 429 may retry after server hint

## 9.3. Requires session recovery
- invalid session
- token expired
- account disabled
- device trust invalidated

---

## 10. Cache invalidation rules

Invalidate relevant surfaces on:
- quest joined → quests list, quest detail, profile stats
- proof submitted → quest detail, quest history, notifications maybe later
- profile updated → profile, header/profile chips
- language/theme changed → local immediate rerender
- logout → purge user-scoped cache and queue

---

## 11. Logout behavior

On logout:
- clear session tokens
- clear user-scoped pending queue or mark inaccessible
- keep only safe anonymous app config
- remove cached profile, notifications, drafts unless product explicitly supports multi-account secure separation

---

## 12. QA scenarios

QA must validate:
1. open app offline with cached feed
2. join quest offline blocked correctly
3. write proof draft offline preserved after app kill
4. regain network resumes upload
5. duplicate submit prevented
6. logout clears sensitive cache
7. stale feed banner appears correctly
8. notification counts do not fake freshness offline
9. session expiry returns user to auth cleanly
10. queued preference updates eventually reconcile

---

## 13. Sprint 01 lock

Sprint 01 must not introduce:
- complex multi-device merge
- offline final submission for trust-sensitive actions
- hidden background sync that user cannot reason about
- queueable financial or legal-signature actions

---

## 14. Chốt cuối

Muôn Nơi mobile phải:
- chịu được mạng yếu
- không đánh lừa người dùng
- không làm mất nội dung họ đã tạo
- và luôn phân biệt rõ giữa:
  - **đã lưu local**
  - **đã đồng bộ server**
  - **đã được xác nhận**
