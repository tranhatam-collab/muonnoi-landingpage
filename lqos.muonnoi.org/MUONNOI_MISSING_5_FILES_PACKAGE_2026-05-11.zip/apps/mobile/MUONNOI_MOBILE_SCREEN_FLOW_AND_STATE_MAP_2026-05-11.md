# MUONNOI_MOBILE_SCREEN_FLOW_AND_STATE_MAP_2026-05-11

**File:** `apps/mobile/MUONNOI_MOBILE_SCREEN_FLOW_AND_STATE_MAP_2026-05-11.md`  
**Status:** Locked for Sprint 01  
**Scope:** iOS + Android mobile app shell, auth, feed, quests, profile, notifications, settings  
**Audience:** Product, Design, Mobile, API, QA  
**Updated:** 2026-05-11

---

## 1. Mục tiêu của file này

File này khóa:
- information architecture cho mobile
- navigation map
- screen inventory
- state inventory
- loading / empty / error / offline patterns
- deep link expectations
- các hành vi tối thiểu cho Sprint 01

Đây là file để:
- Design dựng flow
- Mobile build đúng shell
- API hiểu điểm chạm dữ liệu
- QA có test matrix ổn định

---

## 2. Navigation architecture

## 2.1. App shell

### Root flows
1. Splash
2. Onboarding / pre-auth
3. Auth
4. Main app
5. Modal / overlay flows
6. System / unsupported / maintenance flows

## 2.2. Main app tab bar

Tab bar chuẩn Sprint 01:

1. Home
2. Quests
3. Rooms
4. Notifications
5. Profile

Không mở tab riêng cho AI, Wallet, Invest, Family trong Sprint 01. Các lane này đi qua cards / entry points trong Home hoặc Profile.

## 2.3. Stack rules

Mỗi tab có stack riêng.
Global modal dùng cho:
- sign-in required
- create / join actions
- filter / sort
- proof submission
- report / complaint
- app update required
- permission prompts explanation

---

## 3. Screen inventory

## 3.1. Splash / boot
- Splash screen
- Version check
- Maintenance mode
- Force update gate

### States
- boot/loading
- success → route
- maintenance
- update_required
- fatal_boot_error
- no_network_boot

---

## 3.2. Onboarding / pre-auth
- Welcome
- What Muôn Nơi is
- Core principles
- Choose language
- Sign in / continue as guest entry
- Permissions primer

### States
- first_open
- returning_unsigned
- signed_in_restore
- onboarding_skipped
- permission_soft_prompt

---

## 3.3. Auth
- Sign in
- Sign up
- OTP / magic link confirmation
- Session restore
- Auth error
- Blocked / suspended account screen

### States
- idle
- submitting
- success
- invalid_credentials
- otp_waiting
- otp_expired
- rate_limited
- suspended
- network_error
- offline_cached_session

---

## 3.4. Home tab
- Feed home
- Feed filter sheet
- Post detail
- Topic detail
- Quest promo card
- Family / Health / Travel entry cards
- Search entry
- Empty home for new users

### States
- initial_loading
- skeleton
- loaded
- refresh_in_progress
- empty_personalized
- empty_generic
- partial_content
- error_retry
- offline_cached
- stale_data_banner

---

## 3.5. Quests tab
- Quest index
- Quest category list
- Quest detail
- Join quest confirmation
- Submit proof flow
- Proof submitted receipt
- Quest history
- Quest saved / in-progress / completed

### States
- loading_catalog
- loaded_catalog
- empty_catalog
- join_submitting
- join_success
- proof_draft
- proof_uploading
- proof_submitted_pending_review
- proof_reviewed_verified
- proof_reviewed_rejected
- proof_sync_pending_offline
- offline_blocked_for_upload

---

## 3.6. Rooms tab
- Rooms index
- Room detail
- Join room
- Room members preview
- Room rules
- Room activity list

### States
- loading
- loaded
- empty
- join_pending
- joined
- blocked_room
- invite_only
- error
- offline_read_only

---

## 3.7. Notifications tab
- Notification list
- Notification detail route out
- Notification settings entry

### States
- loading
- loaded
- empty
- permission_not_granted
- stale
- mark_all_read_in_progress
- offline_cached

---

## 3.8. Profile tab
- My profile
- Public profile preview
- Trust / verify summary
- Quest stats
- Saved items
- Settings entry
- Help / support entry

### States
- loading
- loaded
- incomplete_profile
- verify_pending
- verify_locked
- error
- offline_cached

---

## 3.9. Settings
- Account
- Language
- Theme
- Notifications
- Privacy
- Data usage
- Logout
- Delete/deactivate account request
- Legal links
- Report issue

### States
- loading
- loaded
- updating_preference
- saved
- failed_save
- offline_read_only

---

## 3.10. Support / trust
- Report content
- Complaint form
- Safety / trust help
- Appeal state
- Confirmation receipt

### States
- draft
- submitting
- submitted
- failed
- duplicate_warning
- offline_queue_allowed_or_not_allowed

---

## 4. Primary user flows

## 4.1. New user first launch
Splash  
→ Welcome  
→ Principles  
→ Language  
→ Sign in / Sign up / Continue as guest  
→ Home empty state with guided cards

## 4.2. Returning signed user
Splash  
→ Session restore  
→ Home

## 4.3. User joins a quest
Home/Quests  
→ Quest detail  
→ Join quest  
→ Joined state  
→ Submit proof  
→ Pending review  
→ Verified / Rejected outcome

## 4.4. User opens notification
Notifications  
→ tap item  
→ navigate to target screen  
→ mark read  
→ back to list preserves scroll position

## 4.5. User changes settings
Profile  
→ Settings  
→ update  
→ optimistic state  
→ saved or rollback with error

## 4.6. User reports abuse / problem
Post detail or Profile or Settings  
→ Report / Complaint  
→ choose type  
→ add details  
→ submit  
→ confirmation receipt  
→ support status available later

---

## 5. Deep link map

## 5.1. Supported deep links Sprint 01
- `muonnoi://home`
- `muonnoi://quests`
- `muonnoi://quest/{id}`
- `muonnoi://rooms`
- `muonnoi://room/{id}`
- `muonnoi://profile/{id}`
- `muonnoi://notifications`
- `muonnoi://settings`
- `muonnoi://support/report`
- `https://muonnoi.org/quest/{id}` → route into app if installed

## 5.2. Unsupported deep links
Unsupported / unknown routes must:
- open fallback screen
- show safe message
- not crash app

---

## 6. State map rules

## 6.1. Every network-backed screen must define
- loading
- success
- empty
- error
- offline_cached or offline_unavailable

## 6.2. Mutation screens must define
- idle
- submitting
- success
- recoverable_failure
- non_recoverable_failure

## 6.3. Long-running flows must define
- step_progress
- cancel behavior
- retry behavior
- resumed_after_background

---

## 7. Offline rules

## 7.1. Read behavior
- Home: cached read allowed
- Quest catalog: cached read allowed
- Quest detail: cached read allowed if previously loaded
- Rooms list/detail: cached read allowed
- Notifications: cached read allowed, may be stale
- Settings: read allowed from local snapshot

## 7.2. Write behavior
- Preference changes: queue if safe
- Quest join: do not fake success offline unless specifically supported by API
- Proof submission with media: hold in local draft and queue upload when online
- Complaints/report: allow draft save; submit only when online unless later queue policy is approved

---

## 8. Error design rules

## 8.1. Error copy must be
- short
- actionable
- non-technical
- not blame user

## 8.2. Error actions
Each error state must offer one of:
- Retry
- Go back
- Continue offline
- Contact support
- Save draft

---

## 9. Accessibility baseline

Every screen must support:
- Dynamic type / text scaling
- Screen reader labels
- Visible focus order where relevant
- 44x44 minimum tap target
- contrast-safe action buttons
- reduced motion fallback where applicable

---

## 10. Notification taxonomy touchpoints

Notification destinations supported in Sprint 01:
- quest approved
- quest rejected
- room invite
- room update
- support response
- trust / verify update
- product announcement (limited)

No growth-spam notifications in Sprint 01.

---

## 11. QA screen matrix

QA must test each screen in:
1. fresh install
2. returning install
3. signed out
4. signed in
5. poor network
6. offline
7. permission denied
8. stale cache
9. dark mode
10. light mode
11. VI
12. EN

---

## 12. Sprint 01 must-have screens

### Must exist
- Splash
- Welcome/onboarding
- Sign in
- Home
- Quest list
- Quest detail
- Proof submission draft
- Notifications list
- Profile
- Settings
- Report/complaint
- Maintenance / force update / generic error

### Can be shell-only in Sprint 01
- Rooms detail
- Verify detail
- Saved items
- Public profile preview
- Support status timeline

---

## 13. Decision lock

If a new screen is proposed during Sprint 01, it must answer:
1. Which existing flow fails without it?
2. What state does it replace or improve?
3. Does it require API work?
4. Does it delay release gate?

If those answers are weak, the screen moves to Sprint 02.
