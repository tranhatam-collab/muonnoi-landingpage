# MUONNOI_STORE_SUBMISSION_REQUIREMENTS_2026-05-11

**File:** `docs/launch/MUONNOI_STORE_SUBMISSION_REQUIREMENTS_2026-05-11.md`  
**Status:** Pre-submission lock  
**Scope:** App Store + Google Play readiness for Muôn Nơi mobile  
**Audience:** Founder, Product, Mobile, QA, Legal/Policy, Support  
**Updated:** 2026-05-11

---

## 1. Mục tiêu của file này

File này khóa các yêu cầu trước khi gửi app Muôn Nơi lên:
- Apple App Store
- Google Play Store

Mục tiêu:
- không bị reject vì thiếu chính sách
- không xin quyền vô lý
- không mô tả sai sản phẩm
- không đưa tính năng chưa sẵn sàng lên store listing
- không tạo rủi ro pháp lý, trust hoặc moderation

---

## 2. Định vị sản phẩm dùng cho store

## 2.1. Tên mô tả ngắn
Muôn Nơi là một social-first, privacy-first, module-first app để con người tham gia cộng đồng, theo dõi quests, lưu bằng chứng hành trình và kết nối với các lớp đời sống thật.

## 2.2. Không dùng trên store
Không dùng các tuyên bố:
- kiếm tiền dễ
- bảo đảm thu nhập
- đầu tư sinh lời
- chơi là có tiền
- chữa lành / chẩn đoán sức khỏe
- tư vấn y tế / pháp lý / tài chính chuyên sâu
- app cho trẻ em nếu chưa có full child safety system

## 2.3. Mô tả đúng
App nên được mô tả như:
- social + quests + community + trust-aware mobile experience
- value-first
- no trackers / privacy-first where applicable
- purposeful participation, not addictive play

---

## 3. Store metadata checklist

## 3.1. Bắt buộc
- app name
- subtitle / short description
- long description
- primary category
- secondary category if needed
- app icon
- splash / launch assets
- screenshots for supported sizes
- privacy policy URL
- terms URL
- support URL
- support email
- copyright / publisher info

## 3.2. Nên có
- feature graphic (Android)
- app preview video later if stable
- release notes template
- localization copy for VI and EN

---

## 4. Permissions matrix

## 4.1. Notification permission
Allowed if:
- notifications already function
- user benefit is clear
- soft prompt is shown first

Store-safe reason:
- quest updates
- review results
- room/activity updates
- support responses

Not acceptable:
- growth spam
- re-engagement only
- ambiguous “stay updated” language

## 4.2. Camera / photos
Only request if proof/photo upload exists in the released build.

Must explain:
- upload proof for quest completion
- update profile media if applicable

Do not request on first launch unless required by immediate flow.

## 4.3. Location
Do not request for Sprint 01 unless essential and live.

If used:
- justify with travel / local experience / geotag proof
- prefer when-in-use
- provide no-location fallback when possible

## 4.4. Contacts
Do not request in Sprint 01.

## 4.5. Microphone
Do not request in Sprint 01 unless audio/video proof is truly released.

## 4.6. Health / fitness data
Do not request in Sprint 01 unless health module is released and reviewed for policy fit.

---

## 5. Privacy and policy requirements

## 5.1. Required public pages
Before store submission, these URLs must exist and be public:
- Privacy Policy
- Terms of Use
- Support / Contact
- Report Abuse / Complaints
- Community standards summary if UGC exists

## 5.2. Privacy claims must match reality
If store listing says:
- no tracking
- privacy-first
- minimal data

then app behavior, SDKs, analytics, crash reporting, and backend logging must not contradict that.

## 5.3. Third-party SDK discipline
List every SDK included in production build:
- analytics
- crash reporting
- push
- auth
- payments
- media
- maps

If a SDK collects data, it must be reflected in privacy disclosures.

---

## 6. User-generated content policy

Because Muôn Nơi includes feed, rooms, profile, proof, and community flows, the app must have:
- content reporting path
- block / mute or equivalent mitigation if applicable
- moderation response process
- safety contact/support
- ability to remove prohibited content server-side

Store submission should not proceed unless report flow is present in build or clearly reachable.

---

## 7. Account management requirements

## 7.1. Minimum
- sign in
- logout
- session expiry handling
- support contact for account issues

## 7.2. If account deletion is legally or policy-required for the surface
Need:
- in-app delete/deactivate request entry
or
- clear in-app path to request deletion

This should be present before public scale.

---

## 8. Content safety boundaries

## 8.1. Must not position app as
- medical diagnosis
- mental health treatment
- financial advisory
- securities offering
- gambling
- play-to-earn app promising money

## 8.2. If Family surfaces are linked later
Do not market as child-directed app unless full children compliance is implemented.

---

## 9. Store assets checklist

## 9.1. Screenshots must show real app states
Use:
- home feed
- quests
- proof flow
- notifications
- profile/settings

Do not show fake features not in release.

## 9.2. Screenshot copy rules
Must be:
- short
- factual
- consistent with product truth
- non-hype

Avoid:
- “world’s best”
- “earn instantly”
- “guaranteed”
- “change your life now”

---

## 10. Release readiness before submission

App is ready for store submission only if:
1. crash-free smoke build available
2. login works
3. core navigation works
4. at least one real quest flow works or is safely disabled
5. report/complaint path exists
6. privacy and terms URLs are live
7. permissions are justified and tested
8. no placeholder copy/icons/screenshots remain
9. support inbox and owner are assigned
10. release gates pass

---

## 11. Apple-specific caution points

- Be careful with wording around earning money, investment, or financial opportunities.
- Be careful with user-generated content moderation.
- Avoid hidden or undeclared feature flags that materially change the app after review.
- If sign-in is required, guest preview should still be considered if product allows.
- If external payments or memberships exist later, review Apple policy carefully before linking out.

---

## 12. Google Play-specific caution points

- Data safety form must match actual SDK/runtime behavior.
- Sensitive permissions need strong justification.
- Broken login or dead web links often trigger poor review outcomes.
- Repeated policy issues can affect account standing.

---

## 13. Support and operations requirements

Before submission, assign:
- release owner
- support owner
- incident owner
- privacy/contact mailbox
- abuse mailbox
- store credentials owner
- screenshot/localization owner

No submission if these are undefined.

---

## 14. Required pre-submission package

Before shipping to store review, the team must prepare:
- build number + version
- release notes
- screenshot pack
- icon pack
- privacy answers
- test account if reviewer needs it
- support contact
- known issues list
- rollback plan

---

## 15. QA preflight checklist

QA must explicitly validate:
- fresh install
- update from previous build
- sign in
- logout
- bad network
- offline open with cached data
- push permission decline
- camera/photos decline
- deep links
- report flow
- dark mode
- light mode
- VI
- EN

---

## 16. Submission decision rule

If one of the following is not ready, do not submit:
- policy pages
- support ownership
- report flow
- stable auth
- realistic screenshots
- release gates

---

## 17. Chốt cuối

Store submission không phải bước “marketing”.  
Đó là bước xác nhận rằng app Muôn Nơi đã đủ:
- rõ sản phẩm
- rõ chính sách
- rõ hỗ trợ
- rõ quyền riêng tư
- và đủ ổn định để người lạ tải về mà không cần Founder đứng cạnh giải thích.
