# TEAM_READ_ORDER_2026-05-11

**File:** `docs/launch/TEAM_READ_ORDER_2026-05-11.md`  
**Status:** Locked for execution  
**Scope:** Muôn Nơi mobile iOS + Android, public shell, API contract, QA release gates  
**Audience:** Founder, Product, Design, Mobile, API, Platform, QA, Community Ops  
**Updated:** 2026-05-11

---

## 1. Mục tiêu của file này

File này khóa **thứ tự đọc tài liệu và thứ tự bắt đầu công việc** để mọi team không hiểu lệch nhau, không làm rời rạc, và không đẩy build đi trước khi các quyết định nền đã được chốt.

Nguyên tắc chung:

1. Đọc đúng thứ tự.  
2. Không bỏ qua tài liệu nền.  
3. Không mở sprint nếu phần phụ thuộc chưa đọc và chưa chốt owner.  
4. Khi có mâu thuẫn giữa các tài liệu, ưu tiên tài liệu có phạm vi hẹp hơn và ngày mới hơn, trừ khi Founder khóa khác đi.

---

## 2. Bộ tài liệu gốc đang có

### 2.1. Nhóm chiến lược tổng
1. `docs/launch/MUONNOI_LIFE_QUEST_OS_INTEGRATED_MASTER_PLAN_2026.md`
2. `docs/launch/MUONNOI_PUBLIC_LAUNCH_PACKAGE_2026.md`
3. `docs/launch/MUONNOI_LIFE_QUEST_OS_MOBILE_EXECUTION_MASTER_PLAN_2026-05-11.md`
4. `docs/launch/MUONNOI_LQOS_CONTINUATION_PLAN_2026-05-11.md`
5. `docs/launch/MUONNOI_MASTER_PLAN_STATUS_2026-05-11.md`

### 2.2. Nhóm thực thi mobile
6. `apps/mobile/MUONNOI_MOBILE_TEAM_HANDOFF_SPRINT_01_2026-05-11.md`
7. `apps/mobile/MUONNOI_MOBILE_SCREEN_FLOW_AND_STATE_MAP_2026-05-11.md`

### 2.3. Nhóm API
8. `api/contracts/MUONNOI_API_CONTRACT_HANDOFF_FROM_SPRINT_01_2026-05-11.md`
9. `api/contracts/MUONNOI_SYNC_OFFLINE_CACHE_STRATEGY_2026-05-11.md`

### 2.4. Nhóm QA / release
10. `qa/release-gates/MUONNOI_MOBILE_RELEASE_GATES_2026-05-11.md`
11. `qa/release-gates/MUONNOI_RELEASE_RUNBOOK_2026-05-11.md`

### 2.5. Nhóm store / compliance
12. `docs/launch/MUONNOI_STORE_SUBMISSION_REQUIREMENTS_2026-05-11.md`

---

## 3. Thứ tự đọc bắt buộc theo vai trò

## 3.1. Founder / Product Lead

### Đọc theo thứ tự
1. `MUONNOI_MASTER_PLAN_STATUS_2026-05-11.md`
2. `MUONNOI_LIFE_QUEST_OS_MOBILE_EXECUTION_MASTER_PLAN_2026-05-11.md`
3. `MUONNOI_LQOS_CONTINUATION_PLAN_2026-05-11.md`
4. `MUONNOI_PUBLIC_LAUNCH_PACKAGE_2026.md`
5. `MUONNOI_MOBILE_TEAM_HANDOFF_SPRINT_01_2026-05-11.md`
6. `MUONNOI_MOBILE_SCREEN_FLOW_AND_STATE_MAP_2026-05-11.md`
7. `MUONNOI_API_CONTRACT_HANDOFF_FROM_SPRINT_01_2026-05-11.md`
8. `MUONNOI_MOBILE_RELEASE_GATES_2026-05-11.md`
9. `MUONNOI_STORE_SUBMISSION_REQUIREMENTS_2026-05-11.md`

### Kết quả phải chốt
- Sprint 01 phạm vi chính thức
- Những gì không làm trong Sprint 01
- Danh sách owners
- Release target nội bộ / external
- Store submission có vào Sprint 01 hay Sprint 02

---

## 3.2. Product Manager

### Đọc theo thứ tự
1. `MUONNOI_LIFE_QUEST_OS_MOBILE_EXECUTION_MASTER_PLAN_2026-05-11.md`
2. `MUONNOI_MOBILE_TEAM_HANDOFF_SPRINT_01_2026-05-11.md`
3. `MUONNOI_MOBILE_SCREEN_FLOW_AND_STATE_MAP_2026-05-11.md`
4. `MUONNOI_API_CONTRACT_HANDOFF_FROM_SPRINT_01_2026-05-11.md`
5. `MUONNOI_SYNC_OFFLINE_CACHE_STRATEGY_2026-05-11.md`
6. `MUONNOI_MOBILE_RELEASE_GATES_2026-05-11.md`
7. `MUONNOI_RELEASE_RUNBOOK_2026-05-11.md`
8. `MUONNOI_STORE_SUBMISSION_REQUIREMENTS_2026-05-11.md`

### Kết quả phải chốt
- backlog Sprint 01
- acceptance criteria cho từng feature
- dependency map giữa Mobile / API / QA
- definition of done
- launch checklist

---

## 3.3. Design / UX

### Đọc theo thứ tự
1. `MUONNOI_PUBLIC_LAUNCH_PACKAGE_2026.md`
2. `MUONNOI_LIFE_QUEST_OS_MOBILE_EXECUTION_MASTER_PLAN_2026-05-11.md`
3. `MUONNOI_MOBILE_TEAM_HANDOFF_SPRINT_01_2026-05-11.md`
4. `MUONNOI_MOBILE_SCREEN_FLOW_AND_STATE_MAP_2026-05-11.md`
5. `MUONNOI_MOBILE_RELEASE_GATES_2026-05-11.md`
6. `MUONNOI_STORE_SUBMISSION_REQUIREMENTS_2026-05-11.md`

### Kết quả phải chốt
- IA mobile
- tab bar / stack map
- onboarding
- empty/loading/error/offline states
- design tokens / spacing / typography / accessibility
- app store screenshots list

---

## 3.4. Mobile Team

### Đọc theo thứ tự
1. `MUONNOI_MOBILE_TEAM_HANDOFF_SPRINT_01_2026-05-11.md`
2. `MUONNOI_MOBILE_SCREEN_FLOW_AND_STATE_MAP_2026-05-11.md`
3. `MUONNOI_API_CONTRACT_HANDOFF_FROM_SPRINT_01_2026-05-11.md`
4. `MUONNOI_SYNC_OFFLINE_CACHE_STRATEGY_2026-05-11.md`
5. `MUONNOI_MOBILE_RELEASE_GATES_2026-05-11.md`
6. `MUONNOI_RELEASE_RUNBOOK_2026-05-11.md`
7. `MUONNOI_STORE_SUBMISSION_REQUIREMENTS_2026-05-11.md`

### Kết quả phải chốt
- project scaffold
- navigation architecture
- shared state/data layer
- caching policy
- API stubs/mocks
- crash reporting and release build settings

---

## 3.5. API / Backend Team

### Đọc theo thứ tự
1. `MUONNOI_API_CONTRACT_HANDOFF_FROM_SPRINT_01_2026-05-11.md`
2. `MUONNOI_SYNC_OFFLINE_CACHE_STRATEGY_2026-05-11.md`
3. `MUONNOI_MOBILE_TEAM_HANDOFF_SPRINT_01_2026-05-11.md`
4. `MUONNOI_MOBILE_RELEASE_GATES_2026-05-11.md`
5. `MUONNOI_RELEASE_RUNBOOK_2026-05-11.md`

### Kết quả phải chốt
- endpoint list Sprint 01
- auth/session contract
- pagination model
- error code taxonomy
- sync model
- idempotency / retry / conflict rules

---

## 3.6. QA Team

### Đọc theo thứ tự
1. `MUONNOI_MOBILE_RELEASE_GATES_2026-05-11.md`
2. `MUONNOI_RELEASE_RUNBOOK_2026-05-11.md`
3. `MUONNOI_MOBILE_SCREEN_FLOW_AND_STATE_MAP_2026-05-11.md`
4. `MUONNOI_API_CONTRACT_HANDOFF_FROM_SPRINT_01_2026-05-11.md`
5. `MUONNOI_STORE_SUBMISSION_REQUIREMENTS_2026-05-11.md`

### Kết quả phải chốt
- test matrix
- regression checklist
- offline/resume test plan
- notification test plan
- store review preflight checklist

---

## 3.7. Community / Ops / Trust Team

### Đọc theo thứ tự
1. `MUONNOI_PUBLIC_LAUNCH_PACKAGE_2026.md`
2. `MUONNOI_MASTER_PLAN_STATUS_2026-05-11.md`
3. `MUONNOI_STORE_SUBMISSION_REQUIREMENTS_2026-05-11.md`
4. `MUONNOI_RELEASE_RUNBOOK_2026-05-11.md`

### Kết quả phải chốt
- moderation language
- trust/escalation path
- app launch support flow
- app store support email and response flow

---

## 4. Day-1 reading session bắt buộc

## 4.1. Founder kickoff meeting
**Thời lượng:** 60–90 phút

### Agenda
1. Founder restates product truth
2. Product restates Sprint 01 scope
3. Mobile confirms screen list
4. API confirms contract list
5. QA confirms gates
6. Decision log opened
7. Risks acknowledged

## 4.2. Rule
Không ai được mở code Sprint 01 trước khi:
- đã đọc tài liệu theo vai trò
- đã xác nhận owner
- đã có issue/task list tương ứng

---

## 5. Day-1 đầu việc theo team

## 5.1. Product
- chốt Sprint 01 scope
- chốt list screens
- chốt release target
- mở tracking board

## 5.2. Design
- khóa navigation
- khóa screen states
- khóa spacing/token base
- khóa app icon + splash direction

## 5.3. Mobile
- tạo scaffold app
- tạo navigation shell
- tạo auth shell
- tạo feed/quest/profile placeholders
- tạo environment config

## 5.4. API
- tạo mock contract / schema examples
- khóa auth response
- khóa feed/quest/profile endpoints
- khóa offline sync assumptions

## 5.5. QA
- tạo regression sheet
- tạo gate checklist
- tạo test device matrix
- tạo smoke list

---

## 6. Cấm hiểu sai

- Không được xem `MUONNOI_PUBLIC_LAUNCH_PACKAGE` là spec kỹ thuật.
- Không được xem `MOBILE_EXECUTION_MASTER_PLAN` là backlog chi tiết.
- Không được xem `RELEASE_GATES` là thay thế cho test plan.
- Không được xem `STORE_SUBMISSION_REQUIREMENTS` là legal approval hoàn tất.
- Không được bắt đầu coding dựa trên suy đoán thay vì screen/state map.

---

## 7. Ưu tiên khi có mâu thuẫn

Thứ tự ưu tiên:
1. Founder decision log
2. Sprint handoff hiện hành
3. API contract
4. Screen flow and state map
5. Release gates
6. Public launch copy

---

## 8. Chốt cuối

Mục tiêu của bộ tài liệu này không phải để đọc cho đủ.  
Mục tiêu là để mọi team bước vào cùng một đường ray:

**một scope, một flow, một contract, một chuẩn release.**
