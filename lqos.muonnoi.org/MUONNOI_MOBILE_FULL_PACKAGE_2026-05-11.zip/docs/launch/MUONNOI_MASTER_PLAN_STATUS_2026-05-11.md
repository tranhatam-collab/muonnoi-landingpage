# MUONNOI · MASTER PLAN STATUS · 2026-05-11

## 1. Executive status
Muôn Nơi hiện có 4 lớp đang hình thành rõ:
- public shell
- social/app layer
- trust layer
- life quest layer

Mobile plan đã được thêm vào như execution layer, không thay đổi định nghĩa lõi.

## 2. Đã khóa
### Public shell
- homepage direction
- ecosystem page direction
- roadmap page direction
- security page direction
- guide page direction
- verify page direction

### Life Quest OS
- 7 systems defined
- purposeful play
- proof-based economy
- flagship pilot direction

### Mobile
- iOS + Android plan
- 30/90/180 roadmap
- release gates
- team ownership
- KPI value-first

## 3. Đang làm
- chuẩn hóa content public shell
- chuẩn hóa handoff docs
- proof layer / trust layer page continuity
- mobile execution pack

## 4. Chưa khóa hoàn toàn
- feed/index page final production copy
- complaints page final
- admin public page final
- status public page final
- mobile API contract specifics
- store submission pack

## 5. Dependencies
### To ship mobile alpha
Need:
- stable auth/session
- feed read shell
- quest hub data
- proof draft local queue
- privacy/safety/support URLs live

### To ship beta
Need:
- push notification baseline
- proof upload retry
- profile/trust shell
- device QA baseline

### To ship public mobile RC
Need:
- store assets
- policies published
- release gates pass
- crash and offline metrics acceptable

## 6. Top open decisions
1. Final mobile stack confirmation (recommended: React Native + Expo + TS)
2. Auth mechanism final shape for mobile
3. Proof upload media constraints
4. Feature flags per quest vertical
5. Store launch scope by geography

## 7. Red lines
- no tracker-based growth hacks
- no token-first economy
- no addictive feed design
- no module explosion before core stability

## 8. Status summary by lane
### Product
Green with clarifications needed
### Public shell
Yellow-green
### Mobile
Yellow, now structured
### API
Yellow
### QA / Release
Yellow-red until gates and contracts are finalized
