# DEV HANDOFF · ĐƯỜNG MUÔN NƠI · 30-DAY MVP
**Module:** `dulich.muonnoi.org`
**Phase:** Tháng 1 · Đà Lạt only
**Trạng thái:** Ready for dev team
**Đối tượng:** DEV / DESIGN / CONTENT / ADMIN / LEGAL
**Ngày:** 2026-05-11

---

## MỤC LỤC

1. [Tổng quan MVP](#1-tổng-quan-mvp)
2. [Stack đã chốt](#2-stack-đã-chốt)
3. [Repo structure](#3-repo-structure)
4. [D1 Schema đầy đủ](#4-d1-schema-đầy-đủ)
5. [API contracts chi tiết](#5-api-contracts-chi-tiết)
6. [UI flow + screens spec](#6-ui-flow--screens-spec)
7. [30 quest Đà Lạt seed](#7-30-quest-đà-lạt-seed)
8. [Host onboarding flow](#8-host-onboarding-flow)
9. [Proof submission flow](#9-proof-submission-flow)
10. [Admin panel spec](#10-admin-panel-spec)
11. [Security headers + CSP](#11-security-headers--csp)
12. [Sprint plan 4 tuần](#12-sprint-plan-4-tuần)
13. [Definition of Done](#13-definition-of-done)
14. [Test plan](#14-test-plan)

---

## 1. TỔNG QUAN MVP

### 1.1 Scope chính xác

**Có:**
- `dulich.muonnoi.org` shell (public landing + quest list + host list)
- Identity SSO basic (email + phone OTP)
- 30 quest Đà Lạt
- 50 Local Host onboarded
- Submission flow với proof: text + photo + GPS + optional video
- AI pre-review basic
- Manual admin approval cho proof + booking
- Wallet placeholder (chưa thanh toán thật, log balance)
- Trust score basic
- Public profile cho user + host
- Admin panel cho team

**KHÔNG có (move to M2-3):**
- Cross-game synergy
- Cohort / Lớp X
- Auto-escrow Stripe live
- Insurance live contract
- Other 6 quests
- Mobile app (web responsive only)

### 1.2 Mục tiêu cuối Tháng 1

| Metric | Target |
|---|---|
| Registered users | 500-1000 |
| Active hosts | 50 |
| Active verifiers | 30 |
| Quests live | 30 |
| Quest completions | 100 |
| Verified proofs | 50 |
| Paid local experiences | 20 |
| NPS | baseline (target 40+) |
| Sponsor conversations | 10 |

---

## 2. STACK ĐÃ CHỐT

### 2.1 Frontend

```
Framework:    Vanilla HTML + CSS + JS (theo nguyên tắc Muôn Nơi)
              NO React/Vue/Svelte cho public shell
              NO external CDN
              NO third-party libs
Build:        None (static files)
Routing:      Server-side via Cloudflare Pages _redirects
              + History API cho SPA-like nav
Styling:      CSS từ assets/ui.css (Muôn Nơi base) + dulich-specific
JS:           Plain modules ES2022
Storage:      localStorage cho session token, sessionStorage cho temp UI state
```

**Lý do:** giữ đúng nguyên tắc Muôn Nơi "no external libs, no CDN, no trackers, minimal surface".

### 2.2 Backend

```
Runtime:      Cloudflare Workers
Language:     TypeScript 5.x
Database:     Cloudflare D1 (SQLite)
Object Store: Cloudflare R2 (cho proof images/videos)
Auth:         HttpOnly Secure SameSite cookie + JWT
Rate Limit:   D1-based + Workers KV
Email:        Resend
SMS:          Twilio (Đà Lạt VN — local SMS gateway)
Hash:         Web Crypto API (SHA-256)
```

### 2.3 AI Service

```
Endpoint:     api.ai.muonnoi.org
Models:       Claude (Anthropic) cho reasoning, OpenAI vision cho image check
Tasks:        proof pre-screen, fraud detection, mission ranking
Cost target:  < $0.02/active user/day
```

### 2.4 Payment (manual phase 1)

```
Phase 1 (M1):   Manual approve via admin panel, Stripe payout to host monthly
Phase 2 (M2-3): Stripe Connect + escrow auto-release
Phase 3 (M4+):  Local VN payment (MoMo, ZaloPay, VNPay)
```

### 2.5 Hosting

```
Pages:        Cloudflare Pages (dulich.muonnoi.org)
Workers:      api.muonnoi.org (shared) hoặc api.dulich.muonnoi.org (specific)
DNS:          Cloudflare
SSL:          Cloudflare auto
```

---

## 3. REPO STRUCTURE

```
muonnoi/
├── apps/
│   ├── web/
│   │   └── public/
│   │       ├── index.html                       # muonnoi.org existing
│   │       ├── quests/
│   │       │   └── index.html                   # NEW: Life Quest OS intro
│   │       └── assets/
│   │           ├── ui.css
│   │           └── ui.js
│   │
│   └── dulich/                                  # NEW
│       └── public/
│           ├── index.html                       # dulich.muonnoi.org landing
│           ├── quests/
│           │   ├── index.html                   # quest list
│           │   └── [id].html                    # quest detail (template)
│           ├── hosts/
│           │   ├── index.html                   # host list
│           │   └── [id].html                    # host detail
│           ├── submit-proof/
│           │   └── [mission_id].html
│           ├── me/
│           │   ├── index.html                   # profile
│           │   └── wallet.html
│           ├── admin/
│           │   ├── index.html
│           │   ├── hosts.html
│           │   ├── quests.html
│           │   ├── submissions.html
│           │   └── complaints.html
│           ├── assets/
│           │   ├── dulich.css                   # extends ui.css
│           │   ├── dulich.js
│           │   └── img/                         # static images
│           ├── _headers                         # CSP + security
│           ├── _redirects                       # routing
│           ├── manifest.json
│           ├── robots.txt
│           └── sitemap.xml
│
└── workers/
    └── api/
        ├── src/
        │   ├── index.ts                          # router entry
        │   ├── routes/
        │   │   ├── auth.ts
        │   │   ├── missions.ts
        │   │   ├── hosts.ts
        │   │   ├── submissions.ts
        │   │   ├── proofs.ts
        │   │   ├── reviews.ts
        │   │   ├── rewards.ts
        │   │   ├── profile.ts
        │   │   ├── wallet.ts
        │   │   ├── admin.ts
        │   │   └── complaints.ts
        │   ├── lib/
        │   │   ├── db.ts
        │   │   ├── auth.ts
        │   │   ├── hash.ts
        │   │   ├── rate-limit.ts
        │   │   ├── proof-validator.ts
        │   │   └── ai-client.ts
        │   ├── schema/
        │   │   └── d1.sql
        │   └── seed/
        │       ├── dalat-quests.ts              # 30 quests seed
        │       └── dalat-hosts.ts               # initial host data
        ├── wrangler.toml
        └── package.json
```

---

## 4. D1 SCHEMA ĐẦY ĐỦ

### 4.1 Tables core (16 tables)

```sql
-- ============================================
-- USERS & IDENTITY
-- ============================================

CREATE TABLE users (
  id TEXT PRIMARY KEY,
  handle TEXT UNIQUE NOT NULL,
  email TEXT UNIQUE,
  phone TEXT UNIQUE,
  display_name TEXT NOT NULL,
  avatar_url TEXT,
  kyc_tier INTEGER DEFAULT 0,
  trust_score INTEGER DEFAULT 0,
  total_xp INTEGER DEFAULT 0,
  total_skill INTEGER DEFAULT 0,
  total_impact INTEGER DEFAULT 0,
  is_admin INTEGER DEFAULT 0,
  status TEXT DEFAULT 'active',
  created_at INTEGER NOT NULL,
  updated_at INTEGER NOT NULL
);

CREATE TABLE profiles (
  user_id TEXT PRIMARY KEY,
  bio TEXT,
  city TEXT,
  country TEXT,
  languages TEXT,                  -- comma list: 'vi,en,fr'
  interests TEXT,                  -- json array
  goals TEXT,                      -- json array
  visibility TEXT DEFAULT 'public', -- public/friends/private
  FOREIGN KEY (user_id) REFERENCES users(id)
);

CREATE TABLE sessions (
  id TEXT PRIMARY KEY,
  user_id TEXT NOT NULL,
  token_hash TEXT NOT NULL,
  expires_at INTEGER NOT NULL,
  created_at INTEGER NOT NULL,
  user_agent TEXT,
  ip_hash TEXT,
  FOREIGN KEY (user_id) REFERENCES users(id)
);

CREATE INDEX idx_sessions_user ON sessions(user_id);
CREATE INDEX idx_sessions_token ON sessions(token_hash);

-- ============================================
-- MISSIONS & QUESTS
-- ============================================

CREATE TABLE missions (
  id TEXT PRIMARY KEY,
  quest_id TEXT NOT NULL,           -- 'dulich' for now
  category TEXT NOT NULL,           -- 'see' / 'do' / 'connect' / 'create'
  title_vi TEXT NOT NULL,
  title_en TEXT,
  description_vi TEXT NOT NULL,
  description_en TEXT,
  location_name TEXT,
  location_lat REAL,
  location_lng REAL,
  city TEXT,
  proof_type TEXT NOT NULL,         -- 'text' / 'photo' / 'gps' / 'host_sig' / 'multi'
  proof_requirements TEXT NOT NULL, -- json array
  duration_min INTEGER,
  difficulty INTEGER DEFAULT 1,     -- 1-5
  reward_xp INTEGER NOT NULL,
  reward_trust INTEGER DEFAULT 0,
  reward_credit INTEGER DEFAULT 0,
  reward_earning_usd REAL DEFAULT 0,
  host_required INTEGER DEFAULT 0,  -- bool
  required_verifiers INTEGER DEFAULT 1,
  sponsor_id TEXT,
  domain_signals TEXT,              -- 'community_trust,culture'
  status TEXT DEFAULT 'active',
  created_at INTEGER NOT NULL,
  updated_at INTEGER NOT NULL
);

CREATE INDEX idx_missions_quest ON missions(quest_id);
CREATE INDEX idx_missions_city ON missions(city);

-- ============================================
-- HOSTS (specific cho dulich)
-- ============================================

CREATE TABLE hosts (
  id TEXT PRIMARY KEY,
  user_id TEXT NOT NULL,
  type TEXT NOT NULL,                -- 'homestay'/'guide'/'artisan'/'family'/'cafe'/'farm'
  display_name TEXT NOT NULL,
  bio_vi TEXT,
  bio_en TEXT,
  city TEXT NOT NULL,
  address TEXT,
  contact_phone TEXT,
  languages TEXT,
  verification_tier INTEGER DEFAULT 1,
  rating REAL DEFAULT 0,
  total_guests INTEGER DEFAULT 0,
  total_quests INTEGER DEFAULT 0,
  status TEXT DEFAULT 'pending',     -- pending/training/active/suspended
  insurance_policy_id TEXT,
  created_at INTEGER NOT NULL,
  approved_at INTEGER,
  FOREIGN KEY (user_id) REFERENCES users(id)
);

CREATE INDEX idx_hosts_city ON hosts(city);
CREATE INDEX idx_hosts_status ON hosts(status);

CREATE TABLE host_quests (
  host_id TEXT NOT NULL,
  mission_id TEXT NOT NULL,
  price_usd REAL,
  capacity_per_day INTEGER DEFAULT 1,
  active INTEGER DEFAULT 1,
  PRIMARY KEY (host_id, mission_id),
  FOREIGN KEY (host_id) REFERENCES hosts(id),
  FOREIGN KEY (mission_id) REFERENCES missions(id)
);

CREATE TABLE host_signatures (
  id TEXT PRIMARY KEY,
  host_id TEXT NOT NULL,
  user_id TEXT NOT NULL,
  mission_id TEXT NOT NULL,
  submission_id TEXT NOT NULL,
  signature_hash TEXT NOT NULL,
  signed_at INTEGER NOT NULL,
  FOREIGN KEY (host_id) REFERENCES hosts(id)
);

-- ============================================
-- BOOKINGS & SUBMISSIONS
-- ============================================

CREATE TABLE bookings (
  id TEXT PRIMARY KEY,
  user_id TEXT NOT NULL,
  host_id TEXT NOT NULL,
  mission_id TEXT NOT NULL,
  scheduled_at INTEGER NOT NULL,
  status TEXT DEFAULT 'pending',     -- pending/confirmed/completed/cancelled
  amount_usd REAL,
  host_payout_usd REAL,
  platform_fee_usd REAL,
  payment_status TEXT DEFAULT 'pending',
  created_at INTEGER NOT NULL,
  FOREIGN KEY (user_id) REFERENCES users(id),
  FOREIGN KEY (host_id) REFERENCES hosts(id),
  FOREIGN KEY (mission_id) REFERENCES missions(id)
);

CREATE TABLE submissions (
  id TEXT PRIMARY KEY,
  user_id TEXT NOT NULL,
  mission_id TEXT NOT NULL,
  booking_id TEXT,
  proof_text TEXT,
  ai_score REAL,
  ai_flags TEXT,                     -- json
  status TEXT DEFAULT 'pending',     -- pending/ai_passed/community_review/approved/rejected
  created_at INTEGER NOT NULL,
  completed_at INTEGER,
  FOREIGN KEY (user_id) REFERENCES users(id),
  FOREIGN KEY (mission_id) REFERENCES missions(id)
);

CREATE INDEX idx_submissions_user ON submissions(user_id);
CREATE INDEX idx_submissions_status ON submissions(status);

-- ============================================
-- PROOFS
-- ============================================

CREATE TABLE proofs (
  id TEXT PRIMARY KEY,
  submission_id TEXT NOT NULL,
  proof_type TEXT NOT NULL,          -- 'photo'/'gps'/'host_sig'/'text'/'video'
  content_url TEXT,                  -- R2 URL hoặc text content
  content_hash TEXT NOT NULL,
  metadata TEXT,                     -- json: gps lat/lng, exif timestamp
  created_at INTEGER NOT NULL,
  FOREIGN KEY (submission_id) REFERENCES submissions(id)
);

CREATE INDEX idx_proofs_submission ON proofs(submission_id);

-- ============================================
-- REVIEWS
-- ============================================

CREATE TABLE reviews (
  id TEXT PRIMARY KEY,
  submission_id TEXT NOT NULL,
  reviewer_id TEXT NOT NULL,
  reviewer_role TEXT NOT NULL,       -- 'community'/'host'/'admin'
  verdict TEXT NOT NULL,             -- 'pass'/'fail'/'needs_more'
  notes TEXT,
  created_at INTEGER NOT NULL,
  FOREIGN KEY (submission_id) REFERENCES submissions(id),
  FOREIGN KEY (reviewer_id) REFERENCES users(id)
);

CREATE TABLE host_ratings (
  id TEXT PRIMARY KEY,
  host_id TEXT NOT NULL,
  user_id TEXT NOT NULL,
  booking_id TEXT NOT NULL,
  stars INTEGER NOT NULL,            -- 1-5
  comment TEXT,
  created_at INTEGER NOT NULL,
  FOREIGN KEY (host_id) REFERENCES hosts(id)
);

-- ============================================
-- RECEIPTS (proof of completion, hash-based)
-- ============================================

CREATE TABLE receipts (
  id TEXT PRIMARY KEY,
  submission_id TEXT NOT NULL,
  user_id TEXT NOT NULL,
  proof_hash TEXT NOT NULL,
  reward_payload TEXT NOT NULL,      -- json
  domain_signals TEXT,
  exportable_as_vc INTEGER DEFAULT 1,
  created_at INTEGER NOT NULL,
  FOREIGN KEY (submission_id) REFERENCES submissions(id)
);

CREATE INDEX idx_receipts_user ON receipts(user_id);

-- ============================================
-- TRUST EVENTS
-- ============================================

CREATE TABLE trust_events (
  id TEXT PRIMARY KEY,
  user_id TEXT NOT NULL,
  source TEXT NOT NULL,              -- 'mission'/'review'/'host'/'verifier'/'fraud_penalty'
  delta INTEGER NOT NULL,
  reason TEXT NOT NULL,
  reference_id TEXT,                 -- submission_id, review_id, etc
  created_at INTEGER NOT NULL,
  FOREIGN KEY (user_id) REFERENCES users(id)
);

-- ============================================
-- WALLETS
-- ============================================

CREATE TABLE wallets (
  user_id TEXT PRIMARY KEY,
  credit_balance INTEGER DEFAULT 0,
  earning_balance_usd REAL DEFAULT 0,
  pending_balance_usd REAL DEFAULT 0,
  total_earned_usd REAL DEFAULT 0,
  updated_at INTEGER NOT NULL,
  FOREIGN KEY (user_id) REFERENCES users(id)
);

CREATE TABLE wallet_transactions (
  id TEXT PRIMARY KEY,
  user_id TEXT NOT NULL,
  type TEXT NOT NULL,                -- 'earning'/'payout'/'credit_add'/'credit_spend'
  amount REAL NOT NULL,
  currency TEXT NOT NULL,            -- 'usd'/'credit'
  reference TEXT,
  status TEXT DEFAULT 'completed',
  created_at INTEGER NOT NULL,
  FOREIGN KEY (user_id) REFERENCES users(id)
);

-- ============================================
-- COMPLAINTS & AUDIT
-- ============================================

CREATE TABLE complaints (
  id TEXT PRIMARY KEY,
  user_id TEXT NOT NULL,
  target_type TEXT NOT NULL,         -- 'user'/'host'/'mission'/'submission'/'booking'
  target_id TEXT NOT NULL,
  reason TEXT NOT NULL,
  evidence TEXT,
  status TEXT DEFAULT 'open',        -- open/under_review/resolved/dismissed
  admin_notes TEXT,
  created_at INTEGER NOT NULL,
  resolved_at INTEGER
);

CREATE TABLE audit_logs (
  id TEXT PRIMARY KEY,
  actor_id TEXT,
  action TEXT NOT NULL,
  target_type TEXT,
  target_id TEXT,
  meta TEXT,
  ip_hash TEXT,
  created_at INTEGER NOT NULL
);

CREATE INDEX idx_audit_actor ON audit_logs(actor_id);
CREATE INDEX idx_audit_action ON audit_logs(action);
```

### 4.2 Constraints quan trọng

- All `id` fields: 16-char nanoid prefix với loại entity (e.g., `usr_xxx`, `m_xxx`, `sub_xxx`)
- `created_at`/`updated_at`: Unix timestamp (seconds)
- `kyc_tier`: 0=email, 1=phone, 2=ID, 3=address+ref, 4=in-person
- All TEXT fields validated server-side (length, content)
- No nullable foreign keys (use status flags instead)

---

## 5. API CONTRACTS CHI TIẾT

### 5.1 Auth endpoints

```
POST /api/auth/email-start
  Body: { email: string }
  Returns: { ok: true, data: { challenge_id: string } }

POST /api/auth/email-verify
  Body: { challenge_id: string, code: string }
  Returns: { ok: true, data: { token: string, user: User } }
  Sets cookie: session=...; HttpOnly; Secure; SameSite=Strict

POST /api/auth/phone-start
  Body: { phone: string }       // +84 format
  Returns: { ok: true, data: { challenge_id: string } }

POST /api/auth/phone-verify
  Body: { challenge_id: string, code: string }
  Returns: { ok: true, data: { token: string } }

POST /api/auth/logout
  Returns: { ok: true }

GET /api/auth/me
  Returns: { ok: true, data: { user: User, profile: Profile } }
```

### 5.2 Mission endpoints

```
GET /api/missions/list?quest_id=dulich&city=dalat&category=do&limit=20&offset=0
  Returns: { ok: true, data: { missions: Mission[], total: number } }

GET /api/missions/get?id=m_xxx
  Returns: { ok: true, data: { mission: Mission, hosts: Host[] } }

POST /api/missions/accept
  Body: { mission_id: string, host_id?: string, scheduled_at?: number }
  Returns: { ok: true, data: { booking?: Booking, mission: Mission } }

GET /api/missions/me/active
  Returns: { ok: true, data: { missions: Mission[] } }
```

### 5.3 Host endpoints

```
GET /api/hosts/list?city=dalat&type=homestay&limit=20
  Returns: { ok: true, data: { hosts: Host[], total: number } }

GET /api/hosts/get?id=h_xxx
  Returns: { ok: true, data: { host: Host, quests: Mission[], ratings: HostRating[] } }

POST /api/hosts/apply
  Body: { type, display_name, bio_vi, city, address, contact_phone, languages }
  Returns: { ok: true, data: { host_id: string } }
  Status starts as 'pending', admin must approve.

POST /api/hosts/sign-proof
  Body: { booking_id: string, signature: string }  // host signs after experience
  Requires: host role
  Returns: { ok: true, data: { signature_id: string, hash: string } }
```

### 5.4 Submission + Proof endpoints

```
POST /api/submissions/create
  Body: {
    mission_id: string,
    booking_id?: string,
    proof_text: string,
    proofs: [
      { type: 'photo', content_url: string, metadata: { exif, gps, timestamp } },
      { type: 'gps', metadata: { lat, lng, accuracy, timestamp } },
      { type: 'host_sig', metadata: { host_id, signature_hash } }
    ]
  }
  Returns: { ok: true, data: { submission_id: string, status: 'pending'|'ai_passed' } }

POST /api/proofs/upload-url
  Body: { mime_type: string }
  Returns: { ok: true, data: { upload_url: string, key: string } }
  // Pre-signed R2 URL, client uploads directly

GET /api/submissions/get?id=sub_xxx
  Returns: { ok: true, data: { submission: Submission, proofs: Proof[], reviews: Review[] } }

GET /api/submissions/me?status=pending
  Returns: { ok: true, data: { submissions: Submission[] } }
```

### 5.5 Review endpoints

```
GET /api/reviews/pending
  Requires: trust_score >= 50 (community verifier)
  Returns: { ok: true, data: { submissions: Submission[] } }

POST /api/reviews/create
  Body: { submission_id: string, verdict: 'pass'|'fail'|'needs_more', notes?: string }
  Returns: { ok: true, data: { review_id: string } }
```

### 5.6 Profile + Wallet endpoints

```
GET /api/me/profile
  Returns: { ok: true, data: { user, profile, stats: { xp, trust, impact, streak } } }

PATCH /api/me/profile
  Body: { bio?, city?, country?, languages?, interests?, goals?, visibility? }
  Returns: { ok: true }

GET /api/me/wallet
  Returns: { ok: true, data: { wallet: Wallet, transactions: Transaction[] } }

POST /api/me/wallet/withdraw
  Body: { amount_usd: number, method: 'bank'|'stripe', details }
  Returns: { ok: true, data: { withdrawal_id: string } }
  Phase 1: creates request, admin processes manually
```

### 5.7 Trust + Receipt endpoints

```
GET /api/trust/score?user_id=usr_xxx
  Returns: { ok: true, data: { trust_score, total_xp, total_skill, total_impact, receipts_count } }

GET /api/receipts/get?id=rcpt_xxx
  Returns: { ok: true, data: { receipt: Receipt } }

GET /api/receipts/export-vc?id=rcpt_xxx
  Returns: { ok: true, data: { vc: VerifiableCredential } }
  // W3C VC format for export
```

### 5.8 Admin endpoints (require is_admin=1)

```
GET    /api/admin/hosts/pending
PATCH  /api/admin/hosts/{id}/approve
PATCH  /api/admin/hosts/{id}/reject
GET    /api/admin/submissions/queue
PATCH  /api/admin/submissions/{id}/approve
PATCH  /api/admin/submissions/{id}/reject
GET    /api/admin/complaints/open
PATCH  /api/admin/complaints/{id}/resolve
GET    /api/admin/audit?action=...&actor=...
POST   /api/admin/users/{id}/trust-penalty
       Body: { delta: number, reason: string }
```

### 5.9 Response format chuẩn

**Success:**
```json
{ "ok": true, "data": {...}, "meta": { "request_id": "req_xxx" } }
```

**Error:**
```json
{
  "ok": false,
  "error": "invalid_input",
  "message": "Tin nhắn lỗi cho user (VI/EN)",
  "details": { "field": "email", "rule": "required" },
  "meta": { "request_id": "req_xxx" }
}
```

**Error codes:**
- `invalid_input` (400)
- `unauthorized` (401)
- `forbidden` (403)
- `not_found` (404)
- `rate_limited` (429)
- `internal_error` (500)

---

## 6. UI FLOW + SCREENS SPEC

### 6.1 Public landing `dulich.muonnoi.org/`

**Above the fold:**
- Hero: "Đường Muôn Nơi · Mỗi điểm đến là một thử thách"
- Subtitle: "Khám phá Đà Lạt qua nhiệm vụ thật, gặp người thật, làm điều thật."
- CTA primary: "Bắt đầu hành trình" → /quests
- CTA secondary: "Trở thành Local Host" → /hosts/apply

**Below the fold:**
- 3 cards: How it works (See → Do → Connect → Share)
- 3 quest highlights (random featured)
- 3 host stories (testimonial cards)
- Stats: "30 quests · 50 hosts · Đà Lạt"
- Footer Muôn Nơi standard

### 6.2 Quest list `/quests`

**Layout:** Grid 1-col mobile, 2-col tablet, 3-col desktop

**Filters bar:**
- City (Đà Lạt only M1)
- Category (See/Do/Connect/Create)
- Duration (< 1h / half-day / full-day / multi-day)
- Difficulty (1-5)
- Price (free / paid)

**Quest card:**
- Hero image
- Title VI/EN toggle
- Location pin + distance from user
- Duration + difficulty
- Reward (XP + Trust badge)
- Price (or "Free")
- "Tham gia" CTA

### 6.3 Quest detail `/quest/[id]`

**Sections:**
1. Hero image + title
2. Description đầy đủ
3. Map (mini Leaflet hoặc static map)
4. What you'll do (bullets)
5. Proof requirements (text + photo + GPS, etc.)
6. Available hosts (cards với rating + price)
7. Reviews (testimonials previous travelers)
8. CTA: "Đặt với host" hoặc "Tự đi solo"

### 6.4 Host detail `/host/[id]`

**Sections:**
1. Profile photo + name + city
2. Bio
3. Languages + verification badges
4. Rating (stars + total guests)
5. Available quests
6. Reviews
7. Contact (via Muôn Nơi messaging only)

### 6.5 Submit proof `/submit-proof/[mission_id]`

**Step-by-step wizard:**

**Step 1: Confirm mission**
- Recap mission details
- Confirm completion date

**Step 2: Upload proof**
- Photo upload (drag-drop, max 5 photos, JPG/PNG, < 10MB each)
- Auto-extract EXIF (timestamp, GPS)
- GPS capture (request user permission)
- Optional video upload (max 60s, < 50MB)
- Text description (min 100 chars, max 2000)

**Step 3: Host signature (if applicable)**
- Show QR code → host scans → signs digitally
- Or host enters short code on their app

**Step 4: Review + submit**
- Preview all proofs
- Confirm + submit
- Show "AI reviewing..." spinner
- Result: auto-approved / pending review / rejected

### 6.6 Profile `/me`

**Tabs:**
- Active quests
- Completed quests (with receipts)
- Trust score breakdown
- Hosts I've worked with
- Stories I've created
- Wallet (separate page)

### 6.7 Admin panel `/admin`

**Dashboard:**
- Pending hosts (count)
- Pending submissions (count)
- Open complaints (count)
- Today's metrics: new users, completed quests, payments

**Sections:**
- Hosts management (approve/reject + view profile + view submissions)
- Submissions queue (review + approve/reject + add notes)
- Quests management (create/edit/disable)
- Complaints (resolve workflow)
- Audit log viewer

---

## 7. 30 QUEST ĐÀ LẠT SEED

### Nhóm 1 — Đường ít người biết (6 quests)

**Q1: Bình minh đèo Mimosa**
- Type: See
- Description: Đến đỉnh đèo Mimosa trước 5:30 sáng, chứng kiến bình minh trên biển sương Đà Lạt
- Proof: Photo GPS + EXIF timestamp before 6:00 AM
- Reward: 50 XP, 5 Trust
- Duration: 2h
- Difficulty: 2 (cần dậy sớm)
- Price: Free

**Q2: Suối Tía Đam Bri ít chạm tay**
- Type: See + Connect
- Description: Tìm 1 góc Suối Tía cách ngọn thác chính 2km về thượng nguồn, ngồi 30 phút quan sát
- Proof: Photo GPS + text reflection ≥ 200 chữ
- Reward: 60 XP, 8 Trust
- Duration: 3h
- Difficulty: 3
- Price: Free

**Q3: Tổ điểm Tâm An**
- Type: See + Do
- Description: Đến tổ điểm Tâm An, một góc thiền giữa rừng thông, thực hành thiền hành 20 phút
- Proof: Photo + text về cảm nhận
- Reward: 50 XP, 5 Trust
- Duration: 1.5h
- Difficulty: 1
- Price: Free

**Q4: Làng K'Ho Cil**
- Type: See + Connect (host required)
- Description: Đến làng K'Ho Cil, gặp 1 gia đình K'Ho, nghe câu chuyện về cồng chiêng
- Proof: Photo + host signature + text 300 chữ về câu chuyện
- Reward: 80 XP, 12 Trust
- Duration: 4h
- Difficulty: 2
- Price: $15-25 (host fee)

**Q5: Vườn dâu Cầu Đất bình minh**
- Type: Do + Connect (host required)
- Description: Tham gia hái dâu sáng sớm 6h với gia đình nông dân Cầu Đất
- Proof: Photo (hái dâu) + host signature + 1 hộp dâu mang về
- Reward: 60 XP, 8 Trust
- Duration: 3h
- Difficulty: 2
- Price: $12-18

**Q6: Lối mòn Lang Biang ít người**
- Type: See
- Description: Đi lối mòn cạnh đỉnh Lang Biang (không phải trail chính), ghi lại 3 loài hoa rừng
- Proof: 3+ photos GPS + tên 3 loài hoa
- Reward: 70 XP, 10 Trust
- Duration: 5h
- Difficulty: 4
- Price: Free

### Nhóm 2 — Local host gia đình (6 quests)

**Q7: Bữa cơm gia đình K'Ho**
- Type: Connect (host required)
- Description: Ăn 1 bữa cơm chiều với gia đình K'Ho, học 1 món ăn truyền thống
- Proof: Photo bữa ăn + host signature + recipe ghi tay
- Reward: 80 XP, 15 Trust
- Duration: 3h
- Difficulty: 1
- Price: $20-30

**Q8: Cà phê sáng với bác chăm dâu**
- Type: Connect (host required)
- Description: Uống cà phê 1 giờ sáng với bác Đông, người đã chăm vườn dâu Cầu Đất 30 năm
- Proof: Photo + host signature + text về câu chuyện đời bác
- Reward: 70 XP, 12 Trust
- Duration: 1.5h
- Difficulty: 1
- Price: $8-12

**Q9: Học pha cà phê đặc sản**
- Type: Do + Connect (host required)
- Description: 2 giờ với master barista Đà Lạt, học pha 3 phương pháp (V60, Aeropress, Espresso)
- Proof: Video pha cà phê + host signature
- Reward: 90 XP, 15 Trust
- Duration: 2h
- Difficulty: 2
- Price: $25-35

**Q10: Học làm rượu cần**
- Type: Do + Connect (host required)
- Description: 1 buổi học làm rượu cần với gia đình K'Ho, mang về 1 hũ ủ
- Proof: Photo các bước + host signature
- Reward: 100 XP, 20 Trust
- Duration: 4h
- Difficulty: 2
- Price: $30-50

**Q11: Nghe chuyện chiến tranh từ cụ già**
- Type: Connect (host required)
- Description: 1 giờ với cụ Hùng, cựu chiến binh, nghe chuyện Đà Lạt thời chiến
- Proof: Audio recording (consent) + transcript 500 chữ + host signature
- Reward: 100 XP, 25 Trust
- Duration: 1.5h
- Difficulty: 1
- Price: $10 (gift to cụ)

**Q12: Học vẽ thổ cẩm**
- Type: Do + Connect (host required)
- Description: 2 giờ học cơ bản vẽ pattern thổ cẩm K'Ho
- Proof: Photo tác phẩm + host signature
- Reward: 80 XP, 12 Trust
- Duration: 2h
- Difficulty: 3
- Price: $20-30

### Nhóm 3 — Nghề thủ công (6 quests)

**Q13-Q18:** Làm tơ tằm, dệt thổ cẩm, làm rượu cần master, làm mứt, làm trà artichoke, làm gốm
- Tất cả: host required, $25-60, 2-5h duration, reward 80-120 XP

### Nhóm 4 — Câu chuyện thật (6 quests)

**Q19-Q24:** Phỏng vấn cụ già, ghi nghề sắp mất, viết về café gia đình, kể truyền thuyết K'Ho, ghi lễ hội, viết về ngọn núi
- Tất cả: 500+ word output, peer review required, reward 80-100 XP, free hoặc small host fee

### Nhóm 5 — Tạo guide (6 quests)

**Q25-Q30:** Tạo 1-day Đà Lạt off-tourism, K'Ho experience, specialty coffee trail, strawberry farm trail, sunrise trail, family-cuisine trail
- Output: full guide đăng public với photos, map, schedule, costs
- Peer review by 3 verifiers
- Reward 120-150 XP, eligible for sponsor revenue share

**Chi tiết đầy đủ 30 quest sẽ ở file riêng:** `QUEST_TAXONOMY_DULICH_DALAT_V1.md`

---

## 8. HOST ONBOARDING FLOW

### 8.1 Application steps

```
1. User registers as standard user (kyc_tier 1: email + phone)
2. User clicks "Trở thành Local Host"
3. Form:
   - Type (homestay/guide/artisan/family/cafe/farm)
   - Display name
   - Bio (VI required, EN optional)
   - City + address
   - Contact phone
   - Languages
   - Why you want to host (essay 200+ words)
4. Submit application (status: pending)
5. Admin reviews within 48h
   - Background check VN ID
   - Phone verification
   - Reference call (if provided)
6. If approved → status: training
7. Training: 4-hour offline session in Đà Lạt
   - Hospitality basics
   - Safety protocols
   - Muôn Nơi values
   - Insurance overview
   - Trial guest setup
8. Trial guest: 1 paid guest within 14 days
9. If trial OK → status: active, kyc_tier upgraded to 3
```

### 8.2 Host responsibilities

- Respond bookings within 24h
- Show up on time
- Provide safe, authentic experience
- Sign proof for guest after experience
- Comply Muôn Nơi safety guidelines
- Report any issues immediately

### 8.3 Host rewards

- 90% of booking fee
- Insurance coverage during host activity
- Visibility in Muôn Nơi
- Trust score boost per successful quest
- Path to Featured Host (top 10% by rating)

---

## 9. PROOF SUBMISSION FLOW

### 9.1 Frontend flow

```
User completes mission IRL
  ↓
Opens /submit-proof/[mission_id]
  ↓
Wizard step 1: Confirm
Wizard step 2: Upload photos (drag-drop)
  - Client extracts EXIF
  - Validates timestamp ≤ 24h ago
  - Validates GPS within 5km of mission location (if applicable)
Wizard step 3: GPS capture (if required)
  - Browser geolocation API
  - User confirms
Wizard step 4: Host signature (if host_required)
  - QR code shown
  - Host scans → confirms via own app
  - Server generates signature_hash
Wizard step 5: Text reflection
  - Min/max char enforced
  - AI suggests structure if user stuck
Wizard step 6: Review + submit
```

### 9.2 Backend processing

```
POST /api/submissions/create
  ↓
Validate input (size, type, length)
  ↓
Upload photos to R2 → store keys
  ↓
Insert submission (status: pending)
  ↓
Insert proofs
  ↓
Queue AI pre-review job
  ↓
Return submission_id
  ↓
AI Worker picks job:
  - Photo authenticity check (no AI-gen)
  - GPS sanity check (within radius)
  - Text quality (length, coherence)
  - Plagiarism check (against past submissions)
  - Compute ai_score (0-1)
  - Compute ai_flags (json)
  ↓
If ai_score > 0.8 + no flags + simple proof:
  status → approved
  Trigger reward
If ai_score 0.5-0.8 or has minor flags:
  status → community_review
  Queue to verifiers
If ai_score < 0.5 or major flags:
  status → admin_review
  Queue to admin
```

### 9.3 Reward trigger

```
On submission approved:
  1. Insert receipt with proof_hash
  2. Update wallets (credit/earning)
  3. Insert trust_events
  4. Update users.total_xp, trust_score, etc.
  5. Send notification (email + in-app)
  6. If host involved → update host.total_guests, total_quests
```

---

## 10. ADMIN PANEL SPEC

### 10.1 Sections

**Dashboard `/admin`**
- KPIs: registered users today, completed quests today, pending submissions, pending hosts, open complaints
- Recent activity feed (last 50 events)

**Hosts `/admin/hosts`**
- Tabs: Pending / Training / Active / Suspended
- Each host card: photo, name, city, type, applied date, action buttons
- Bulk approve / reject
- View full host profile

**Submissions `/admin/submissions`**
- Queue: pending, community_review, admin_review
- Sort by: oldest first, AI flagged, high reward
- View submission detail:
  - All proofs
  - AI score + flags
  - User profile + trust score
  - Past submissions
  - Approve / Reject / Send back for more
- Bulk approve simple cases

**Quests `/admin/quests`**
- List all 30 quests
- Edit title, description, reward, status
- Create new quest
- Disable/enable

**Complaints `/admin/complaints`**
- Open complaints list
- Resolve workflow:
  - Investigate
  - Add admin notes
  - Take action (refund, trust penalty, host suspension, etc.)
  - Notify reporter + target

**Audit `/admin/audit`**
- Filter by actor, action, target, date range
- Export to CSV

### 10.2 Admin actions logged

Every admin action logs to `audit_logs`:
- approve_host, reject_host, suspend_host
- approve_submission, reject_submission
- resolve_complaint
- trust_penalty
- create_quest, update_quest, disable_quest
- user_suspend

---

## 11. SECURITY HEADERS + CSP

### 11.1 `_headers` file

```
/*
  X-Content-Type-Options: nosniff
  X-Frame-Options: DENY
  Referrer-Policy: strict-origin-when-cross-origin
  Permissions-Policy: geolocation=(self), microphone=(), camera=(self), payment=()
  Strict-Transport-Security: max-age=31536000; includeSubDomains; preload
  Content-Security-Policy: default-src 'self'; base-uri 'self'; object-src 'none'; frame-ancestors 'none'; img-src 'self' data: https://*.r2.cloudflarestorage.com; style-src 'self' 'unsafe-inline'; script-src 'self'; connect-src 'self' https://api.muonnoi.org https://api.ai.muonnoi.org; form-action 'self';

/api/*
  Access-Control-Allow-Origin: https://dulich.muonnoi.org
  Access-Control-Allow-Credentials: true
  Access-Control-Allow-Methods: GET, POST, PATCH, DELETE, OPTIONS
  Access-Control-Allow-Headers: Content-Type, Authorization
```

### 11.2 Session cookie

```javascript
Set-Cookie: session=<jwt>;
  HttpOnly;
  Secure;
  SameSite=Strict;
  Path=/;
  Max-Age=2592000;          // 30 days
  Domain=.muonnoi.org;       // share across subdomains
```

### 11.3 Rate limiting

```
/api/auth/email-start    5 req / 15 min / IP
/api/auth/email-verify   10 req / 5 min / IP
/api/submissions/create  20 req / day / user
/api/proofs/upload-url   100 req / day / user
/api/* (default)         300 req / 5 min / user
```

### 11.4 Input validation

- All TEXT fields: server-side length validation
- Email: RFC 5322 regex
- Phone: E.164 format (+84...)
- Image upload: max 10MB, MIME check, magic byte check
- Video upload: max 50MB, MIME check
- Coordinates: validate -90≤lat≤90, -180≤lng≤180

---

## 12. SPRINT PLAN 4 TUẦN

### Tuần 1: Lock + UI shell + Content
**Day 1-2 (Monday-Tuesday):**
- [ ] CEO approve master plan + dev handoff
- [ ] DNS dulich.muonnoi.org setup
- [ ] Cloudflare Pages + Worker projects created
- [ ] D1 instance provisioned
- [ ] R2 bucket setup
- [ ] Legal counsel retained (VN + Singapore)

**Day 3-4 (Wednesday-Thursday):**
- [ ] Design: quest card + host card + proof card + profile card components
- [ ] Design: mockup 6 main screens
- [ ] Content: 30 quest specs writen (Vietnamese only M1)
- [ ] Content: 5 sample story examples

**Day 5-7 (Friday-Sunday):**
- [ ] Dev: dulich.muonnoi.org landing page
- [ ] Dev: quest list page (static data first)
- [ ] Dev: quest detail page
- [ ] Dev: host list page (static)
- [ ] Tích hợp muonnoi.org/quests intro page

### Tuần 2: Backend MVP
**Day 8-10:**
- [ ] D1 schema deployed (all 16 tables)
- [ ] Auth endpoints (email-start, verify, logout, me)
- [ ] Mission endpoints (list, get)
- [ ] Host endpoints (list, get, apply)
- [ ] Seed 30 quests + 5 sample hosts

**Day 11-12:**
- [ ] Submission endpoints (create, get, me)
- [ ] Proof endpoints (upload-url, processing)
- [ ] R2 integration for media uploads
- [ ] AI pre-review Worker

**Day 13-14:**
- [ ] Review endpoints (community + admin)
- [ ] Receipt generation with hash
- [ ] Trust events + wallet update
- [ ] Admin endpoints (basic)

### Tuần 3: Pilot onboard
**Day 15-17:**
- [ ] Frontend submission wizard
- [ ] Frontend profile page
- [ ] Admin panel basic (host approval, submission queue)
- [ ] Email notifications (Resend integration)

**Day 18-19:**
- [ ] Onboard 50 hosts Đà Lạt (Anh Tâm + team outreach)
- [ ] Host training session offline (4h, Đà Lạt)
- [ ] Sign host agreements + insurance contract
- [ ] Internal test 30 users

**Day 20-21:**
- [ ] Bug bash
- [ ] Performance optimization
- [ ] Security review
- [ ] Legal copy review

### Tuần 4: Soft launch
**Day 22-24:**
- [ ] Soft launch to 100 beta users
- [ ] Monitor metrics dashboard
- [ ] Daily standup, rapid fix

**Day 25-27:**
- [ ] Open to 500 users target
- [ ] Outreach Đà Lạt community Facebook groups
- [ ] Influencer partnerships (5-10 micro)
- [ ] Tourism board Lâm Đồng pre-meeting

**Day 28-30:**
- [ ] Tổng kết tháng: metrics report
- [ ] Retro meeting
- [ ] Decision: continue / pivot / pause
- [ ] Sponsor pipeline review (10 conversations target)
- [ ] Plan Tháng 2: mở Sài Gòn + Hà Nội + start Học Đời

---

## 13. DEFINITION OF DONE

### 13.1 Cho mỗi feature

- [ ] Code written + reviewed by 1 other dev
- [ ] Tests written (unit + integration)
- [ ] CSP compliant
- [ ] Mobile responsive
- [ ] Vietnamese copy reviewed by editor
- [ ] English copy (if M1 EN-ready)
- [ ] Accessibility basic (semantic HTML, contrast, keyboard nav)
- [ ] Performance: page load < 2s on 4G
- [ ] Security: input validation server-side
- [ ] Documented in README

### 13.2 Cho MVP launch (cuối tuần 4)

- [ ] All 30 quests live, tested
- [ ] All 50 hosts approved, trained
- [ ] All flows tested end-to-end (register → submit → review → reward)
- [ ] Admin panel functional
- [ ] Privacy + Terms pages live
- [ ] Insurance contract signed
- [ ] Emergency support line (24/7 cho M1 only Đà Lạt)
- [ ] Metrics dashboard live
- [ ] 100 beta users tested successfully
- [ ] Zero critical bugs
- [ ] Backup + recovery tested

---

## 14. TEST PLAN

### 14.1 Unit tests (per module)

- Auth: token generation, validation, expiry
- Hash: proof_hash deterministic, reproducible
- Validators: email/phone/coordinate edge cases
- AI client: error handling, retry logic

### 14.2 Integration tests

- Full user journey: register → accept mission → submit proof → AI review → community review → reward
- Host journey: apply → admin approve → training → trial guest → first paid guest
- Admin journey: view queue → approve submission → trust event recorded
- Complaint journey: file → admin investigate → resolve

### 14.3 Load tests

- 1000 concurrent users
- 100 simultaneous proof uploads
- 10K mission list queries / min

### 14.4 Security tests

- SQL injection (via D1 parameterized queries)
- XSS (CSP + escaping)
- CSRF (SameSite cookie)
- Rate limiting effective
- Auth token cannot be stolen via XHR

### 14.5 UAT (User Acceptance Test) Đà Lạt

- 20 real users complete 1 quest each
- 5 real hosts sign 5 different guests
- Feedback session with each
- NPS measurement

---

## 15. POST-LAUNCH MONITORING

### 15.1 Metrics dashboard live tracking

```
- New registrations / day
- Active users / day
- Quest accepts / day
- Submissions / day
- AI auto-approval rate
- Avg time submission → approval
- Host bookings / day
- Revenue today
- Complaint rate
- NPS rolling 7-day
- D7, D30 retention
```

### 15.2 Alerts

- AI service down → alert eng team
- Submission queue > 50 pending → alert admin
- Complaint rate > 5% / day → alert team
- Trust score abnormality → alert anti-fraud
- Server error rate > 1% → page on-call

### 15.3 Weekly review

- Founder + product + design + eng weekly meeting
- Review metrics
- User feedback synthesis
- Bug priorities
- Next week sprint planning

---

## 16. CONTACT MATRIX

| Issue type | First contact | Response time |
|---|---|---|
| Production down | On-call eng | < 15 min |
| Critical bug | Eng lead | < 1h |
| User complaint | Support team | < 24h |
| Host emergency (Đà Lạt only) | Local ops 24/7 hotline | < 30 min |
| Legal question | Legal counsel | < 48h |
| Press inquiry | Founder | < 24h |

---

## 17. FILES SẼ TẠO SAU FILE NÀY

1. `QUEST_TAXONOMY_DULICH_DALAT_V1.md` — 30 quest chi tiết đầy đủ
2. `PROOF_AND_REWARD_RULES.md` — rules + edge cases
3. `HOST_VERIFICATION_AND_SAFETY_POLICY.md` — KYC + safety + insurance
4. `MISSION_ENGINE_API_CONTRACT.md` — đầy đủ OpenAPI spec
5. `QUEST_UI_FLOW_SPEC.md` — Figma + wireframes
6. `ADMIN_PANEL_SPEC.md` — detailed admin workflows
7. `LEGAL_TOS_DULICH_VN.md` — Terms of Service tiếng Việt
8. `LEGAL_PRIVACY_DULICH.md` — Privacy policy

---

**Document version:** v1.0
**Date:** 2026-05-11
**Status:** READY FOR DEV TEAM
**Prepared for:** Trần Hà Tâm · Muôn Nơi Engineering Team

**Câu chốt:**

> Mục tiêu Tháng 1 không phải scale. Là **validate**. 500 users hoàn thành 100 quest thật ở Đà Lạt, với 50 host được trả tiền thật, là đủ để biết hệ này có sống được hay không. Đó là goal duy nhất.
