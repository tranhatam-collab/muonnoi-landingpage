# MUÔN NƠI · LIFE QUEST OS · MASTER PLAN 2026
**Bản chốt cuối cùng — v1.0 FINAL**
**Trạng thái:** Approved by founder · Ready for dev handoff
**Ngày chốt:** 2026-05-11
**Ngôn ngữ:** Tiếng Việt · English brand/tech terms preserved

---

## MỤC LỤC

1. [Định nghĩa cuối cùng](#1-định-nghĩa-cuối-cùng)
2. [Hai nguyên tắc khoá](#2-hai-nguyên-tắc-khoá)
3. [Tên hệ thống chính thức](#3-tên-hệ-thống-chính-thức)
4. [Kiến trúc tổng thể](#4-kiến-trúc-tổng-thể)
5. [Bảy hệ nhiệm vụ — 3 ưu tiên + 4 mở rộng](#5-bảy-hệ-nhiệm-vụ)
6. [Proof Economy — 6 loại điểm](#6-proof-economy)
7. [Mission Engine — schema và API](#7-mission-engine)
8. [AI Layer — 8 trách nhiệm](#8-ai-layer)
9. [User Experience flow chuẩn](#9-user-experience-flow)
10. [Cross-game synergy](#10-cross-game-synergy)
11. [Anti-fraud architecture](#11-anti-fraud-architecture)
12. [Pháp lý theo từng hệ](#12-pháp-lý-theo-từng-hệ)
13. [Cross-domain mapping với Civic OS](#13-cross-domain-mapping)
14. [Tích hợp với muonnoi.org public shell](#14-tích-hợp-public-shell)
15. [Roadmap 30 ngày — chỉ Đường Muôn Nơi Đà Lạt](#15-roadmap-30-ngày)
16. [Roadmap 12 tháng](#16-roadmap-12-tháng)
17. [Mô hình doanh thu](#17-mô-hình-doanh-thu)
18. [Định giá thực tế theo năm](#18-định-giá-thực-tế)
19. [Growth loops](#19-growth-loops)
20. [KPI và anti-metrics](#20-kpi-và-anti-metrics)
21. [Risk register](#21-risk-register)
22. [Cập nhật cây hệ Muôn Nơi tổng](#22-cập-nhật-cây-hệ-tổng)
23. [Next steps](#23-next-steps)
24. [Phụ lục](#24-phụ-lục)

---

## 1. ĐỊNH NGHĨA CUỐI CÙNG

> **Muôn Nơi Life Quest OS là lớp trò chơi đời sống của hệ Muôn Nơi — nơi con người học, đi, làm, sáng tạo, chăm sóc sức khỏe, kết nối gia đình và đóng góp cộng đồng thông qua nhiệm vụ thật, bằng chứng thật, AI hỗ trợ, cộng đồng xác nhận và phần thưởng có trách nhiệm.**

### 1.1 Công thức cốt lõi

```
   Play  →  Learn  →  Build  →  Prove  →  Grow  →  Earn by real value
```

KHÔNG được rút gọn thành `Play → Earn`. Bất kỳ luồng nào bỏ qua Learn/Build/Prove/Grow đều phải bị reject ở design review.

### 1.2 Người chơi tham gia để

- giỏi hơn
- khỏe hơn
- đi được nhiều nơi hơn
- gặp được người thật
- làm được việc thật
- tạo được sản phẩm thật
- có hồ sơ tín nhiệm thật
- có cơ hội thu nhập khi tạo giá trị thật

**KHÔNG phải để "chơi kiếm tiền nhanh".**

### 1.3 Vị trí trong hệ Muôn Nơi

Life Quest OS là **Lớp B (consumer)** trong kiến trúc 3 lớp đã chốt:

- **Lớp A** (Public/Trust): `muonnoi.org`, `docs.muonnoi.org`, `verify.muonnoi.org`
- **Lớp B** (Social + Quests): `app.muonnoi.org` + 7 quest subdomains ← **phần này**
- **Lớp C** (Operator/Civic OS): `lamviec.muonnoi.org` với 12 civilization domains
- **Lớp D** (Core/Backend): `api.*` subdomains

Mỗi nhiệm vụ trong Life Quest sinh ra signal cho 12 domains ở Lớp C — đây là moat chiến lược duy nhất không platform nào có.

---

## 2. HAI NGUYÊN TẮC KHOÁ

### Nguyên tắc 1: Không lấy 100B–1000B USD làm áp lực ngắn hạn

Mục tiêu 100B–1000B USD chỉ là **vision target dài hạn (10+ năm)**, không phải áp lực 24 tháng.

Nếu lấy nó làm áp lực ngắn hạn, hệ sẽ đi sai:
- Token hoá vội → speculation → sụp đổ như Axie
- Growth hack → khai thác dopamine → mất bản sắc Muôn Nơi
- Hứa tiền dễ → user vào vì tiền → đi khi tiền giảm

**Realistic targets:**
- 12 tháng: 1M user, ARR $5M, valuation $50M–$200M
- 5 năm: 35M MAU, ARR $300M+, valuation $8B–$20B
- 10 năm: 140M MAU, ARR $3B, valuation $60B–$150B+

100B trong 10 năm = khó nhưng có cơ. 100B trong 1-2 năm = không cam kết được.

### Nguyên tắc 2: Không xây game gây nghiện

Muôn Nơi đã khoá tinh thần trong `docs.muonnoi.org/system/`: **không feed gây nghiện, không tối ưu outrage, không thu thập hành vi để thao túng**.

Life Quest phải là **purposeful play**, không addiction loop.

**Tham chiếu đúng:** Duolingo, Strava, Khan Academy, Wikipedia. Q1/2026 Duolingo đạt 56.5M DAU bằng habit-loop tốt, không bằng addiction-loop tệ.

**Tham chiếu KHÔNG đi theo:** TikTok feed, casino mechanics, Axie token speculation.

---

## 3. TÊN HỆ THỐNG CHÍNH THỨC

| Loại tên | Sử dụng cho |
|---|---|
| **Muôn Nơi Life Quest OS** | Brand name chính thức, docs, dev, B2B |
| **Hệ Nhiệm Vụ Đời Sống Muôn Nơi** | Tiếng Việt formal, government/NGO |
| **Chơi Để Sống Tốt Hơn** | Public tagline đại chúng |

**KHÔNG dùng:**
- "Play to Earn Muôn Nơi" — sai định vị, kéo về tiền ảo
- "Muôn Nơi Games" — chữ "game" gợi giải trí, không phản ánh giá trị thật
- "Muôn Nơi Web3" — không liên quan, không dùng blockchain công khai

---

## 4. KIẾN TRÚC TỔNG THỂ

### 4.1 Các quest subdomains

```
chochoi.muonnoi.org          Life Quest Hub (daily quests cross-game)
dulich.muonnoi.org           Đường Muôn Nơi · Travel Quest        [ƯU TIÊN 1]
hoctap.muonnoi.org           Học Đời · Learn Quest                 [ƯU TIÊN 2]
family.muonnoi.org           Family Mission                        [ƯU TIÊN 3]
suckhoe.muonnoi.org          Một Ngày Khỏe · Health Rhythm         [Phase 2]
lamviec.muonnoi.org/quest/   Việc Có Lý · Work Quest               [Phase 2]
sangtao.muonnoi.org          Vườn Sáng Tạo · Creative Quest        [Phase 3]
congdong.muonnoi.org         Cồng · Community Hero                 [Phase 3]
```

**Note quan trọng về `lamviec.muonnoi.org`:**
Subdomain này đang là Operator Gateway B2B/NGO (Civic OS Layer C). Consumer Work Quest đi vào **subpath `/quest/`** để không phá định vị B2B đã build. Tách hoàn toàn nếu cần: `vieclam.muonnoi.org`.

### 4.2 Lõi dùng chung (Shared Infrastructure)

```
identity.muonnoi.org         Single sign-on + profile + trust score root
verify.muonnoi.org           KYC tiers, identity verification
wallet.muonnoi.org           Points ledger + earnings + payout
api.muonnoi.org              Public product API
api.ai.muonnoi.org           AI review + personalization
api.flow.iai.one             Workflow execution (shared cross-ecosystem)
api.ai.iai.one               Shared AI capability layer
trust.muonnoi.org            Public trust score profiles (verifiable credentials)
```

### 4.3 Quy tắc kiến trúc

- Mọi quest subdomain dùng **identity SSO** chung
- Mọi điểm/wallet đi qua **wallet.muonnoi.org**
- Mọi proof có hash sinh từ **api.muonnoi.org/proof**
- Mọi AI request đi qua **api.ai.muonnoi.org**
- KHÔNG có database riêng cho từng quest game — dùng D1 chung với schema thống nhất

---

## 5. BẢY HỆ NHIỆM VỤ

### 5.1 Ba ưu tiên 12 tháng đầu

#### HỆ 1 · `dulich.muonnoi.org` — ĐƯỜNG MUÔN NƠI

**Vai trò:** Flagship MVP đầu tiên · Khởi điểm Tháng 1 Đà Lạt

**Một câu định vị:**
> "Mỗi điểm đến là một thử thách. Mỗi thử thách mang một cuộc gặp."

**Vì sao chọn ưu tiên 1:**
- Hợp tinh thần "Muôn Nơi" 100%
- Bắt đầu được ngay ở Đà Lạt (Anh Tâm ở đó, có local network)
- Có trải nghiệm offline thật (proof mạnh)
- Tạo nội dung viral tự nhiên
- Doanh thu rõ ràng: local host, guide, homestay, food trail, experience
- Kết nối tự nhiên với Family, Học, Việc, Cồng

**Cơ chế cốt lõi:**
```
See → Do → Connect → Prove → Share
```

**Loại quest:**
- **See:** đến nơi (GPS proof + photo timestamp)
- **Do:** hoàn thành thử thách (làm món địa phương, học 1 câu, tham gia 1 nghi lễ)
- **Connect:** ăn cơm/uống trà với 1 Local Host (host signature + ghi câu chuyện)
- **Create:** viết guide cho người sau (peer review)

**30 quest Đà Lạt mẫu (chi tiết trong DEV handoff):**

*Nhóm 1 — Đường ít người biết (6):* Tổ điểm Tâm An, suối Tía Đam Bri, đèo Mimosa lúc bình minh, làng K'Ho Cil, vườn dâu Cầu Đất, lối mòn Lang Biang ít người

*Nhóm 2 — Local host gia đình (6):* Bữa cơm với gia đình K'Ho, cà phê sáng với bác chăm dâu, học pha cà phê đặc sản, học làm rượu cần, nghe chuyện chiến tranh từ cụ già, học vẽ thổ cẩm

*Nhóm 3 — Nghề thủ công (6):* Làm tơ tằm, dệt thổ cẩm, làm rượu cần, làm mứt, làm trà artichoke, làm gốm

*Nhóm 4 — Câu chuyện thật (6):* Phỏng vấn 1 cụ già, ghi lại 1 nghề sắp mất, viết về 1 quán café gia đình, kể 1 truyền thuyết K'Ho, ghi lại 1 lễ hội, viết về 1 ngọn núi

*Nhóm 5 — Tạo guide (6):* Hành trình 1 ngày Đà Lạt ít chạm vào tourism, hành trình K'Ho experience, hành trình cafe specialty, hành trình dâu strawberry, hành trình bình minh, hành trình ẩm thực gia đình

**Local Host system:**
- KYC tier 3 (identity + address + 1 reference)
- Onboarding: training 4 giờ + 1 trial guest
- Insurance bundled
- Rating + dispute resolution có audit
- Phí cho host: 90% (Muôn Nơi giữ 10%)

**Người chơi kiếm tiền:**
- Local Host: $20–100/khách/ngày
- Quest Designer: 5–10% sponsor pool
- Travel Buddy: $30–50/ngày
- Travel Creator (sponsored content): theo thoả thuận

**Revenue Muôn Nơi:**
- Booking fee 10%
- City pass: $9–29/tháng/thành phố
- Tourism board partnership: $50K–500K/năm/thành phố
- Travel insurance affiliate: 5–15%
- Premium guide content: $5–20/guide

**Khao khát đánh trúng:** Khám phá (5) + Kết nối (4) + Tạo ra (6)

---

#### HỆ 2 · `hoctap.muonnoi.org` — HỌC ĐỜI

**Vai trò:** Daily retention engine (Duolingo-style nhưng output thật)

**Một câu định vị:**
> "Mỗi ngày học một kỹ năng đời, có bằng chứng thật."

**Cơ chế cốt lõi:**
```
Micro skill → Practice → Proof → Peer validation → Skill map
```

**8 learning paths khởi điểm:**
1. AI cơ bản (5 paths nhỏ: prompt, viết với AI, AI cho công việc, AI sáng tạo, AI an toàn)
2. Ngoại ngữ giao tiếp (Anh, Nhật, Hàn, Trung)
3. Tài chính cá nhân
4. Kỹ năng nghề (code, design, write, video)
5. Kỹ năng sống (nấu ăn, sửa chữa, sơ cứu)
6. Kỹ năng gia đình (dạy con, đối thoại với bạn đời, chăm sóc cha mẹ)
7. Kỹ năng sáng tạo
8. Kinh doanh

**Đặc biệt — Output thật, không chỉ bài tập:**
- Code/design/article published
- Voice recording được peer review (ngoại ngữ)
- Bảng ngân sách 30 ngày thật (tài chính)
- Business plan 1-pager
- Video activity với gia đình (private, AI review only)

**Lớp X (Cohort Learning):**
- 5–15 người cùng học 1 path trong 30 ngày
- Có instructor verified (Senior Teacher status)
- Học phí: 50–500 USD/người
- Mỗi ngày 1 micro-lesson + 1 thử thách + 1 buổi gặp video 30 phút
- Hoàn thành: certificate có hash + rating công khai

**Streak + leagues + leaderboards:**
- Bronze → Silver → Gold → Diamond → Eternal (Duolingo-inspired)
- Streak Freeze (tránh nghiện) + Wellbeing Cap (giới hạn time/ngày)

**Người chơi kiếm tiền:**
- Senior Teacher (≥3 lớp X rating 4.5★): mở Lớp X, hưởng 80% học phí
- Mentor 1-1: $20–100/giờ
- Path Designer: % từ học phí
- Verifier: $0.5–2/verification

**Revenue Muôn Nơi:**
- Subscription Premium: $5–9/tháng
- Lớp X fee: 20% (10% cho Senior Teacher)
- Certificate badge có hash: $5–15/lần
- B2B corporate learning: $20/seat/tháng

**Khao khát:** Trưởng thành (2) + Công nhận (3) + Kết nối (4)

---

#### HỆ 3 · `family.muonnoi.org` — FAMILY MISSION

**Vai trò:** Differentiator cốt lõi · Không platform nào làm Family OS đúng nghĩa

**Một câu định vị:**
> "Gia đình cùng chơi để hiểu nhau, sống tốt hơn và lớn lên cùng nhau."

**KHÔNG phải:**
- Parenting blog
- Group chat gia đình
- Photo sharing app

**LÀ:**
- **Family Operating Layer** trong Human Life OS

**Family Pod:**
- Tối đa 8 người
- Role: parent, child, elder, partner, sibling
- Default private mạnh hơn nhiều
- Trẻ < 13: chỉ tồn tại trong family pod, no public profile

**Quest types:**

*Daily small:* bữa cơm không điện thoại, gọi điện 1 người thân, hỏi 1 câu hiếu kỳ với con

*Weekly bonding:* 1 hoạt động cùng nhau, 1 cuộc nói chuyện sâu, 1 việc thiện cùng

*Monthly milestone:* chuyến đi cuối tuần, dự án gia đình, traditional preservation

*Annual:* family roadmap, financial planning together, photo book

**Family-specific features:**
- **Family Streak** (chia sẻ — không break ngay khi 1 người bỏ)
- **Family Memory Book** (auto-compile từ proofs)
- **AI Family Reflection** (cuối tháng — thành tựu chung + gợi ý)
- **Cross-generation quests** (ông bà - cháu, mẹ - con)

**Quy tắc bảo vệ:**
- Mọi family content default private
- Trẻ em < 13: COPPA/GDPR-K compliant
- Parent có thể duyệt friend request của con
- Không có engagement metric public giữa các family

**Revenue Muôn Nơi:**
- Family Premium: $9/tháng/family (lên tới 8 thành viên)
- AI Family Coach: $5/tháng add-on
- Insurance partnership (Y2, sau pháp lý): family wellness data → discount
- Education partner referral: % từ tuition

**Khao khát:** Kết nối (4) + Ý nghĩa (1) + Tạo ra (6)

---

### 5.2 Bốn hệ mở rộng (Phase 2-3)

#### HỆ 4 · `suckhoe.muonnoi.org` — MỘT NGÀY KHOẺ
**Phase 2 (Tháng 7-9)**
**Một câu:** "Mỗi ngày một hành động nhỏ để sống khỏe hơn, cùng gia đình."
**Pháp lý CỰC QUAN TRỌNG:** KHÔNG chẩn đoán bệnh, KHÔNG thay bác sĩ, KHÔNG tuyên bố chữa bệnh. Chỉ wellness + habit + education.
**Cơ chế:** Daily health habit (5000 bước, ngủ trước 11h, thiền, ăn lành), Family Streak chung, integration Apple Health / Google Fit.
**Revenue:** Wellness subscription $4/tháng, corporate wellness B2B, health coach marketplace 15%, **insurance partnership (lớn — sau pháp lý OK)**.
**Khao khát:** Trưởng thành (2) + Kết nối (4)

#### HỆ 5 · `lamviec.muonnoi.org/quest/` — VIỆC CÓ LÝ
**Phase 2 (Tháng 7-9)**
**Một câu:** "Mỗi công việc nhỏ là một bước xây uy tín thật."
**Cơ chế:** Mission → Submission → Review → Score → Payment / Reputation
**Mission scale:** Micro (5-60 phút, $5-50) · Standard (1-8 giờ, $50-500) · Project (1-4 tuần, $500-5000)
**Khác Fiverr/Upwork:** Không bid war (giá fix), escrow auto-release theo proof (vài giờ thay 5-10 ngày), Trust Score xuất khẩu cross-platform, phí 5% (vs 10-20% market).
**Revenue:** 5% commission, $20/tháng client subscription, $200/seat/tháng enterprise.
**Khao khát:** Tạo ra (6) + Công nhận (3)

#### HỆ 6 · `sangtao.muonnoi.org` — VƯỜN SÁNG TẠO
**Phase 3 (Tháng 10-12)**
**Một câu:** "Mỗi ngày tạo một thứ nhỏ, cộng đồng giúp nó thành hình thật."
**Đo lường:** "co-build count" — bao nhiêu người sẵn sàng cùng làm. KHÔNG đo view count, KHÔNG đo likes.
**Cơ chế:** Daily Create prompt → Garden display → Co-builder bid sức → Project room → Sản phẩm thật → Revenue share.
**Kết nối:** Trực tiếp với AI Workflow Platform (Flow runtime).
**Revenue:** Marketplace fee 10%, creator subscription $9/tháng, sponsored challenges.
**Khao khát:** Tạo ra (6) + Công nhận (3) + Kết nối (4)

#### HỆ 7 · `congdong.muonnoi.org` — CỒNG
**Phase 3 (Tháng 10-12)**
**Một câu:** "Mỗi tuần một việc tốt cho cộng đồng, có bằng chứng và người cùng làm."
**Giá trị chiến lược cực cao:** Đây là game tạo **civic trust score**. Trust Score xuất khẩu được cho job/visa/insurance/school. **Đây là entry point B2G dài hạn — lý do hệ Muôn Nơi có moat thật.**
**Cơ chế:** Quest công ích (dọn rác, dạy trẻ, thăm người già, trồng cây, sửa điểm công cộng, báo cáo môi trường). Hoàn thành theo nhóm 3-10 người, multi-witness proof bắt buộc.
**Revenue:** CSR sponsorship 15-20%, NGO partnerships, city/government grants, verified impact reporting.
**Khao khát:** Ý nghĩa (1) + Kết nối (4) + Công nhận (3)

### 5.3 Life Quest Hub · `chochoi.muonnoi.org`

**Không phải hệ riêng — là HUB tổng hợp daily quests từ 7 hệ.**

Vai trò: nơi user vào mỗi sáng, AI gợi ý 3-5 quest từ toàn 7 hệ dựa trên profile, streak, family context, mục tiêu.

Build từ Tháng 4 sau khi 3 hệ ưu tiên đã có data.

---

## 6. PROOF ECONOMY

### 6.1 Sáu loại điểm

| Điểm | Tên đầy đủ | Nguồn | Đổi tiền? | Vai trò |
|---|---|---|---|---|
| **XP** | Experience Points | Hoàn thành mission | KHÔNG | Level + unlock features |
| **Trust** | Trust Score | Proof multi-witness + consistency | KHÔNG | Reputation, xuất khẩu VC |
| **Impact** | Impact Score | Community Hero verified | KHÔNG | Civic credential |
| **Skill** | Skill Badge | Learn + verified output | KHÔNG | Job market signal |
| **Credit** | Sponsor Credit | Sponsor đặt cọc | → voucher, discount | Brand-funded incentive |
| **Earning** | Real Earnings | Job/sale/contract/host/bounty | → USD/VND payout | Thu nhập thật |

### 6.2 Quy tắc bất khả xâm phạm

1. **XP, Trust, Impact, Skill KHÔNG bao giờ mua bán được** — tài sản phi tài chính
2. **Credit chỉ đổi voucher/discount, KHÔNG đổi USD** — chống cash-out abuse
3. **Earning chỉ từ giá trị thật được tạo ra** — job, sale, contract, host, bounty, revenue share
4. **KHÔNG có token Muôn Nơi** — không bao giờ, không thoả hiệp

### 6.3 Vì sao không token

Token tạo speculation → speculation thu hút người chơi vì tiền → game tạm chậm → token sụp → player đi → game chết.

Đây là cách Axie chết. Cách StepN chết. Cách hàng trăm P2E khác chết.

**Muôn Nơi dùng USD/VND + Proof Receipt (hash) thay token.**

### 6.4 Proof Receipt (thay token)

Mỗi giao dịch sinh Proof Receipt:

```json
{
  "id": "rcpt_8h2k...",
  "type": "mission_completion",
  "user_id": "usr_abc",
  "mission_id": "m_xyz",
  "timestamp": 1736500000,
  "proof_hash": "0x...",
  "verifiers": ["u_1", "u_2", "u_3"],
  "reward": { "xp": 50, "credit": 0, "earning_usd": 5.00 },
  "domain_signals": ["learning", "wellbeing"]
}
```

Receipt:
- Hash on Muôn Nơi internal ledger (không phải public blockchain)
- Export được dưới dạng **Verifiable Credential (W3C VC)**
- Dùng cho: job applications, visa support, insurance, school admissions

### 6.5 Flow tiền vào/ra

```
SOURCES (vào)                          SINKS (ra)
──────────────────────                ──────────────────────
Premium subscriptions                  Mentor/coach payouts (70-80%)
Sponsor quest budgets                  Local host payouts (90%)
Brand mission fees                     Quest verifier rewards
Marketplace fees (5-20%)               Course teacher payouts (80%)
B2B/Enterprise contracts               Task worker earnings (95%)
B2G/NGO contracts                      Community captain stipends
Insurance partnerships                 Refund pool (1-3%)
Tourism board partnerships             
                                       
Target: 60-70% community, 10-15% ops, 15-25% margin
```

---

## 7. MISSION ENGINE

### 7.1 D1 Schema (chi tiết trong DEV handoff)

```sql
users (
  id TEXT PRIMARY KEY,
  handle TEXT UNIQUE NOT NULL,
  display_name TEXT NOT NULL,
  kyc_tier INT DEFAULT 0,
  trust_score INT DEFAULT 0,
  total_xp INT DEFAULT 0,
  created_at INT NOT NULL
);

profiles (
  user_id TEXT PRIMARY KEY,
  bio TEXT,
  city TEXT,
  country TEXT,
  languages TEXT,
  skills TEXT,
  interests TEXT,
  goals TEXT,
  family_pod_id TEXT
);

missions (
  id TEXT PRIMARY KEY,
  quest_id TEXT NOT NULL,         -- dulich, hoctap, family...
  category TEXT NOT NULL,
  title TEXT NOT NULL,
  description TEXT NOT NULL,
  proof_type TEXT NOT NULL,        -- text/image/gps/audio/multi
  duration_min INT,
  difficulty INT,                  -- 1-5
  reward_xp INT NOT NULL,
  reward_credit INT DEFAULT 0,
  reward_earning_usd REAL DEFAULT 0,
  sponsor_id TEXT,
  domain_signals TEXT,             -- 'learning,wellbeing'
  required_verifiers INT DEFAULT 1,
  created_at INT NOT NULL,
  status TEXT DEFAULT 'active'
);

submissions (
  id TEXT PRIMARY KEY,
  user_id TEXT NOT NULL,
  mission_id TEXT NOT NULL,
  proof_payload TEXT NOT NULL,     -- json
  ai_score REAL,
  ai_flags TEXT,                   -- json fraud signals
  status TEXT DEFAULT 'pending',
  created_at INT NOT NULL,
  completed_at INT
);

proofs (
  id TEXT PRIMARY KEY,
  submission_id TEXT NOT NULL,
  proof_type TEXT NOT NULL,
  content TEXT NOT NULL,           -- url/text/hash
  metadata TEXT,                    -- json: gps, exif, timestamp
  created_at INT NOT NULL
);

reviews (
  id TEXT PRIMARY KEY,
  submission_id TEXT NOT NULL,
  reviewer_id TEXT NOT NULL,
  verdict TEXT NOT NULL,           -- pass/fail/needs_more
  notes TEXT,
  created_at INT NOT NULL
);

receipts (
  id TEXT PRIMARY KEY,
  submission_id TEXT NOT NULL,
  proof_hash TEXT NOT NULL,
  reward_payload TEXT NOT NULL,
  domain_signals TEXT,
  created_at INT NOT NULL
);

trust_events (
  id TEXT PRIMARY KEY,
  user_id TEXT NOT NULL,
  source TEXT NOT NULL,            -- mission/review/host/verifier
  delta INT NOT NULL,
  reason TEXT NOT NULL,
  created_at INT NOT NULL
);

wallets (
  user_id TEXT PRIMARY KEY,
  credit_balance INT DEFAULT 0,
  earning_balance_usd REAL DEFAULT 0,
  pending_balance_usd REAL DEFAULT 0,
  updated_at INT NOT NULL
);

family_pods (
  id TEXT PRIMARY KEY,
  name TEXT NOT NULL,
  created_at INT NOT NULL
);

family_members (
  family_id TEXT NOT NULL,
  user_id TEXT NOT NULL,
  role TEXT NOT NULL,
  joined_at INT NOT NULL,
  PRIMARY KEY (family_id, user_id)
);

hosts (
  id TEXT PRIMARY KEY,
  user_id TEXT NOT NULL,
  type TEXT NOT NULL,              -- homestay/guide/artisan/family
  city TEXT NOT NULL,
  verification_tier INT DEFAULT 1,
  rating REAL DEFAULT 0,
  total_guests INT DEFAULT 0,
  status TEXT DEFAULT 'pending',
  created_at INT NOT NULL
);

host_quests (
  host_id TEXT NOT NULL,
  mission_id TEXT NOT NULL,
  price_usd REAL,
  PRIMARY KEY (host_id, mission_id)
);

complaints (
  id TEXT PRIMARY KEY,
  user_id TEXT NOT NULL,
  target_type TEXT NOT NULL,       -- user/host/mission/submission
  target_id TEXT NOT NULL,
  reason TEXT NOT NULL,
  evidence TEXT,
  status TEXT DEFAULT 'open',
  created_at INT NOT NULL
);

audit_logs (
  id TEXT PRIMARY KEY,
  actor_id TEXT NOT NULL,
  action TEXT NOT NULL,
  target TEXT,
  meta TEXT,
  created_at INT NOT NULL
);
```

### 7.2 Core APIs

```
GET    /missions/list?quest_id=...&status=active
GET    /missions/get?id=...
POST   /missions/accept                   # user accepts mission
POST   /submissions/create                # submit proof
GET    /submissions/get?id=...
POST   /reviews/create                    # community review
POST   /proofs/upload                     # upload proof file
GET    /me/profile
PATCH  /me/profile
GET    /me/wallet
POST   /me/wallet/withdraw                # request payout
GET    /trust/score?user_id=...           # public trust score
GET    /receipts/get?id=...
GET    /hosts/list?city=...
POST   /hosts/apply                       # become host
GET    /families/get?id=...
POST   /families/create
POST   /families/invite
POST   /complaints/create
```

API response chuẩn:

```json
{ "ok": true, "data": {...}, "meta": { "request_id": "..." } }
{ "ok": false, "error": "...", "message": "...", "meta": { "request_id": "..." } }
```

---

## 8. AI LAYER

### 8.1 Tám trách nhiệm

1. **Mission Personalization** — gợi ý nhiệm vụ theo profile/streak/family/mục tiêu
2. **Difficulty Adjustment** — Flow Theory: vừa khít khả năng
3. **Journey Summarization** — tóm tắt tuần/tháng thành portfolio
4. **Proof Pre-Review** — image/text/GPS sanity check, AI-gen detection
5. **Fraud Detection** — sock puppet, GPS spoofing, duplicate proof
6. **Community Matching** — gom user cùng interest, mentor-mentee, Lớp X cohort, family compatibility
7. **Next-Step Suggestion** — gợi ý mission tiếp theo
8. **Portfolio Generation** — auto-compile thành public profile (CV alternative)

### 8.2 AI Infrastructure

- `api.ai.muonnoi.org` — main AI service
- `api.ai.iai.one` — shared AI capability layer cross-ecosystem
- `api.flow.iai.one` — workflow execution
- **Models:** Hybrid — Claude/GPT cho reasoning, smaller models cho classification/embedding
- **Target cost:** < $0.02/active user/day
- **Human override always available** — AI = pre-screen only, không decision final

---

## 9. USER EXPERIENCE FLOW

### 9.1 Flow chuẩn

```
User joins muonnoi.org
  ↓
chooses 1-3 quests (dulich/hoctap/family priority)
  ↓
profile setup (interest, city, goal, optional family pod)
  ↓
sees mission list (AI-personalized)
  ↓
accepts a mission
  ↓
performs in real world
  ↓
submits proof (text + photo + GPS + optional video)
  ↓
AI reviews (pre-screen, 70% auto-approve simple, 30% to human)
  ↓
community/host/verifier confirms (when needed)
  ↓
earns XP / Skill / Trust / Impact (+ Credit/Earning if applicable)
  ↓
unlocks next level / room / tool / job / travel quest
  ↓
invites friends/family
  ↓
forms team / cohort
  ↓
creates value
  ↓
earns real income (when value created)
```

### 9.2 Trạng thái nhiệm vụ

```
Available → Joined → In Progress → Submitted → 
AI Reviewed → Peer Reviewed → Verified → Rewarded
                                      ↓
                                  Rejected → Appealed
```

---

## 10. CROSS-GAME SYNERGY

| Hệ | Unlock điều gì | Tại hệ nào |
|---|---|---|
| Đường (dulich) | 3 cities completed | Travel Creator status, sponsored trips |
| Học (hoctap) | Skill badge verified | Higher mission tier ở Việc |
| Family | Family streak ≥30 ngày | Family travel discount ở Đường |
| Việc (lamviec) | Trust ≥80 | Quest Curator role ở Đường |
| Khoẻ (suckhoe) | 30-day streak | Insurance partner discount |
| Sáng tạo (sangtao) | 1 product published | Marketplace listing fee giảm 50% |
| Cồng (congdong) | Impact ≥100 | Civic Verifier role (paid) |

**Triết lý:** Không silo. User càng tham gia nhiều hệ, càng được unlock nhiều giá trị thật.

---

## 11. ANTI-FRAUD ARCHITECTURE

### 11.1 Năm lớp phòng vệ

| Lớp | Cơ chế | Coverage |
|---|---|---|
| L1: Identity | KYC tiers (0-4) | Sybil resistance |
| L2: AI Pre-screen | Image/text/GPS validity, AI-gen detection | 70% obvious fraud |
| L3: Multi-witness | Community quests cần 3+ witnesses | Social proof |
| L4: Random Audit | 5-10% submissions random deep review | Deterrence |
| L5: Trust Penalty | Repeat fraud → trust drop → earning cap drop | Long-term cost |

### 11.2 Per-quest anti-fraud

- **Đường (dulich):** GPS proof + host cryptographic signature + EXIF timestamp/location check
- **Khoẻ (suckhoe):** Device integration (Apple Health/Google Fit) — không self-report
- **Học (hoctap):** Plagiarism check + AI-gen detection cho output
- **Việc (lamviec):** Client review + dispute resolution với audit
- **Cồng (congdong):** Multi-witness mandatory + photo + GPS + timestamp

### 11.3 KYC tier vs earning cap

| Tier | Yêu cầu | Earning cap/tháng |
|---|---|---|
| 0 | Email | $0 |
| 1 | + Phone | $50 |
| 2 | + ID | $500 |
| 3 | + Address + 1 reference | $5000 |
| 4 | + In-person | Unlimited |

---

## 12. PHÁP LÝ THEO TỪNG HỆ

| Hệ | Rủi ro chính | Hành động |
|---|---|---|
| Đường (dulich) | Visa, host liability, tax | Visa = traveler's responsibility (disclaimer), host insurance bundled, local tax reporting |
| Học (hoctap) | Education credentials | Disclaimer "not accredited", partner với accredited institutions cho cert |
| Family | Trẻ em <13 | COPPA/GDPR-K, parental consent, no public profile for minors |
| Việc (lamviec) | Labor classification | Independent contractor (default), 1099/equivalent, NO employment |
| Khoẻ (suckhoe) | Medical advice | "Wellness only, not medical diagnosis" — disclaimer mọi page |
| Sáng tạo (sangtao) | IP ownership | User retains IP, Muôn Nơi gets non-exclusive license to display |
| Cồng (congdong) | Volunteer labor | Quest = volunteer, no employment; donation flow comply local law |

**Global priorities:**
- EU: GDPR + DSA compliance từ ngày 1
- US: CCPA, COPPA, state-by-state tax cho gig workers
- VN: Decree 53/2022, business licensing marketplace
- Singapore: PDPA, MAS nếu financial features
- JP: APPI, gig economy laws

**Legal team setup:**
- Phase 1 (M1-3): Retain 1 VN counsel + 1 international (Singapore-based)
- Phase 2 (M4-12): In-house legal + privacy officer khi 10K user
- Phase 3 (Y2): Jurisdiction counsel cho top-5 markets

---

## 13. CROSS-DOMAIN MAPPING

Mỗi hệ sinh signal cho 12 civilization domains ở `lamviec.muonnoi.org`:

| Hệ Quest | Civic Domains nhận signal |
|---|---|
| Đường (dulich) | community_trust, culture, infrastructure |
| Học (hoctap) | learning, economy |
| Family | family, wellbeing, culture |
| Khoẻ (suckhoe) | health, wellbeing, family |
| Việc (lamviec) | economy, learning, community_trust |
| Sáng tạo (sangtao) | culture, learning, economy, media_integrity |
| Cồng (congdong) | community_trust, environment, governance, culture |

**7 hệ cover trọn 12 domains.** Đây là moat chiến lược không platform nào có.

**Đối tác tiềm năng cho data layer (sau consent + pháp lý):**
- Government (digital society dashboard)
- UNDP, World Bank, WHO
- Insurance industry
- ESG investors
- Academic research (anonymized aggregate)

---

## 14. TÍCH HỢP PUBLIC SHELL

### 14.1 Pages cần thêm vào `muonnoi.org`

```
apps/web/public/quests/index.html         Life Quest OS overview
apps/web/public/quests/dulich.html        Đường Muôn Nơi promo
apps/web/public/quests/hoctap.html        Học Đời promo
apps/web/public/quests/family.html        Family Mission promo
apps/web/public/roadmap/index.html        UPDATE: thêm Phase 5 — Life Quest OS
apps/web/public/ecosystem/index.html      UPDATE: thêm Life Quest Layer
apps/web/public/guide/index.html          UPDATE: thêm How to join quests
apps/web/public/security/index.html       UPDATE: thêm Proof security, host safety, child safety
```

### 14.2 Footer cập nhật

Thêm vào footer của `muonnoi.org` + `app.muonnoi.org`:

```
[Quests]
dulich.muonnoi.org
hoctap.muonnoi.org
family.muonnoi.org
```

---

## 15. ROADMAP 30 NGÀY

**Chỉ làm Đường Muôn Nơi Đà Lạt. Không 5 game cùng lúc.**

### Tuần 1 — Lock + UI shell

**Output files cần khoá:**
```
MUONNOI_LIFE_QUEST_OS_MASTER_PLAN_2026.md     ← file này, đã chốt
DEV_HANDOFF_DULICH_MUONNOI_30_DAY_MVP.md      ← file đi kèm
QUEST_TAXONOMY_V1.md                          ← 30 quest Đà Lạt
PROOF_AND_REWARD_RULES.md                     ← rules cho proof + reward
HOST_VERIFICATION_AND_SAFETY_POLICY.md        ← host KYC + safety
```

**Việc làm tuần 1:**
- Ngày 1-2: Approve master plan, khoá DNS dulich.muonnoi.org, retain legal counsel
- Ngày 3-4: UI shell — quest card, host card, proof submission card, profile card (dùng tokens từ Muôn Nơi brand đã có)
- Ngày 5-7: Landing dulich.muonnoi.org + 30 quest content viết tay (không AI generate)

### Tuần 2 — Build MVP kỹ thuật

**Frontend:**
```
dulich.muonnoi.org/
dulich.muonnoi.org/quests
dulich.muonnoi.org/quest/:id
dulich.muonnoi.org/hosts
dulich.muonnoi.org/host/:id
dulich.muonnoi.org/submit-proof/:mission_id
dulich.muonnoi.org/me/profile
dulich.muonnoi.org/admin (separate URL path)
```

**Backend (Cloudflare Workers + D1):**
```
workers/api/src/routes/missions.ts
workers/api/src/routes/hosts.ts
workers/api/src/routes/submissions.ts
workers/api/src/routes/proofs.ts
workers/api/src/routes/reviews.ts
workers/api/src/routes/rewards.ts
workers/api/src/routes/profile.ts
workers/api/src/routes/admin.ts
workers/api/src/routes/complaints.ts
```

**Admin panel:**
- Duyệt host
- Duyệt quest
- Xem proof submission
- Xử lý complaint
- Audit log viewer

### Tuần 3 — Onboard pilot

**Mục tiêu Đà Lạt:**
- 50 local hosts (homestay, café, farm, artisan, guide, gia đình K'Ho)
- 30 verifiers (peer reviewers)
- 100 beta users (friends + family Muôn Nơi team)
- 30 quests live

**Outreach playbook:**
- Tuần 3 ngày 15-17: Outreach host cá nhân (Anh Tâm + Muôn Nơi team)
- Tuần 3 ngày 18-19: Training session host (4 giờ, offline tại Đà Lạt)
- Tuần 3 ngày 20-21: Trial guests + bug fix

### Tuần 4 — Soft launch

**Mục tiêu:**
- 500 registered users
- 100 quest completions
- 50 verified proofs
- 20 paid local experiences
- NPS baseline
- Completion rate baseline
- Refund/complaint baseline ≤ 5%
- 10 sponsor/partner conversations initiated

**Truyền thông:**
- Đà Lạt community Facebook groups
- Influencer travel VN micro (10K-100K followers): 5-10 partnerships
- Lâm Đồng tourism board pre-meeting

---

## 16. ROADMAP 12 THÁNG

| Tháng | Trọng tâm | Mục tiêu user |
|---|---|---|
| 1 | Đường Muôn Nơi MVP Đà Lạt | 500-1K users |
| 2-3 | Mở Sài Gòn + Hà Nội Travel + Start Học Đời | 10K users |
| 4-6 | Launch Family Mission + Mở chochoi Hub | 50K users |
| 7-9 | Launch Một Ngày Khoẻ + Việc Có Lý | 250K users |
| 10-12 | Launch Vườn Sáng Tạo + Cồng + B2G pilot 1-2 cities | 1M users |

### Năm 2 (M13-24)
- International expansion: Bangkok, Singapore, Tokyo, Paris, NY (Travel)
- Insurance partnership pilot
- ESG sponsor commercial contracts
- Series A/B raised
- 10M users
- ARR $50-150M

### Năm 3 (M25-36)
- Global brand
- 30M+ users
- ARR $300-600M
- Profitable
- B2G commercial scaling

---

## 17. MÔ HÌNH DOANH THU

### Revenue streams

| Stream | Y1 % | Y3 % |
|---|---|---|
| Premium subscriptions | 30% | 25% |
| Marketplace fees | 25% | 30% |
| Sponsor/Brand quests | 15% | 10% |
| Corporate B2B | 10% | 15% |
| B2G/NGO contracts | 5% | 10% |
| Insurance partnerships | 5% | 5% |
| Tourism board | 5% | 3% |
| Travel insurance affiliate | 3% | 2% |
| Other | 2% | 0% |

### Nguyên tắc

**Revenue follows real value.** Không ép user trả tiền trước khi họ thấy giá trị.

---

## 18. ĐỊNH GIÁ THỰC TẾ

| Năm | Users (reg/MAU) | Paying | ARPU | ARR | Valuation |
|---|---|---|---|---|---|
| Y1 | 1M / 200K | 30K | $25 | $750K | $50M-$200M (vision premium) |
| Y2 | 10M / 3M | 400K | $30 | $12M | $300M-$1B |
| Y3 | 30M / 10M | 1.5M | $35 | $52M | $1.5B-$5B |
| Y5 | 100M / 35M | 8M | $40 | $320M | $8B-$20B |
| Y7 | 200M / 70M | 20M | $50 | $1B | $20B-$50B |
| Y10 | 400M / 140M | 50M | $60 | $3B | $60B-$150B+ |

**Cảnh báo 100B-1000B trong 1-2 năm:**

Để đạt $100B trong 1-2 năm, hệ phải có hàng trăm triệu users, doanh thu hàng tỷ USD/năm, network effect cực mạnh, vốn raised >$1B từ tier-1 VC, team cấp thế giới. Mức này chưa từng có ngoài AI infrastructure (OpenAI).

**Em đề xuất:**
- Nội bộ: $5-20B trong 5 năm — realistic stretch
- Public framing: "10-year generational company"
- Từ chối quỹ ép timeline ngắn

---

## 19. GROWTH LOOPS

### Loop 1: Travel
```
Traveler đi city → create story → bạn bè thấy → join Muôn Nơi 
→ become Local Host khi về quê → invite community
```
**K target: 1.6** (mạnh nhất historically)

### Loop 2: Family
```
1 người tạo family pod → mời 3-7 người nhà → cả nhà chơi 
→ share family streak → bạn của gia đình thấy → tạo family pod mới
```
**K target: 1.4**

### Loop 3: Learning
```
Học viên hoàn thành lớp → certificate có hash → share LinkedIn/CV 
→ người khác thấy → join Lớp X
```
**K target: 1.2**

### Loop 4: Work
```
Worker hoàn thành mission → portfolio → client thấy → mời worker khác 
→ team work → invite to Muôn Nơi
```
**K target: 1.3**

### Loop 5: Community
```
Người tham gia community quest → multi-witness verify → local chapter 
→ city captain elected → grow chapter
```
**K target: 1.1** (slow but durable)

### Math kết hợp

K trung bình 1.3, cycle 60 ngày:
- M0: 1K → M6: 6.5K → M12: 145K → M18: 500K → M24: 2M
- + paid acquisition + partnerships → hit 10M Y2

---

## 20. KPI VÀ ANTI-METRICS

### 20.1 North Star

**"Verified Real-World Outputs per Week" (VRWO/wk)**

- Y1: 100K VRWO/week
- Y2: 5M VRWO/week
- Y3: 50M VRWO/week

### 20.2 KPI cốt lõi

| Metric | Target Y1 |
|---|---|
| D7 retention | 40% |
| D30 retention | 25% |
| Quest completion rate | 60%+ |
| Multi-quest user % | 30%+ |
| Avg trust gain/user/mo | 50 |
| Avg earning/active user/mo | $20 |
| NPS | 50+ |
| Fraud rate | <2% |
| Host satisfaction | 4.5★+ |
| Complaint rate | <5% |

### 20.3 Anti-metrics (KHÔNG tracking)

- ❌ Time in app (not a goal)
- ❌ Pure engagement (likes, follows count)
- ❌ Outrage-driven content metrics
- ❌ Ad impression metrics
- ❌ Push notification frequency (cap 1/day)
- ❌ Streak guilt-trip (Streak Freeze available)
- ❌ Token speculation metrics (no token)

---

## 21. RISK REGISTER

| # | Risk | Likelihood | Impact | Mitigation |
|---|---|---|---|---|
| 1 | Fake proof at scale | High | High | 5-layer anti-fraud, random audit, trust penalty |
| 2 | Streak = mild addiction conflict no-addiction principle | Medium | Medium | Streak freeze, wellbeing cap, no public engagement metric |
| 3 | Local host scams travelers | Medium | High | KYC tier 3, insurance bundled, dispute audit |
| 4 | Cross-border legal complexity | High | High | Local counsel top-5 markets, jurisdiction terms |
| 5 | 100B target pressure → bad decisions | High | Critical | Public 10-year framing, reject short-timeline VC |
| 6 | Token speculation pressure | Medium | High | Hard no-token, public commitment in docs |
| 7 | Privacy breach | Low | Critical | Minimal data, encryption at rest, GDPR day 1 |
| 8 | AI hallucination in proof review | Medium | Medium | Human override always, AI = pre-screen only |
| 9 | Quality dilution at scale | High | Medium | Senior Teacher / City Captain / Verifier tiers |
| 10 | FAANG copies | High | Medium | First-mover + community trust + VN advantage + Civic OS moat |
| 11 | Country bans (financial features) | Medium | High | Feature flags per country, conservative legal |
| 12 | Founder team burnout | Medium | Critical | Phased rollout, KHÔNG 7-game-cùng-lúc |
| 13 | Child safety incident | Low | Critical | COPPA/GDPR-K strict, no public minor profile, parental consent |
| 14 | Travel safety incident | Medium | High | Host insurance, emergency contact, safety checklist, 24/7 support |

---

## 22. CẬP NHẬT CÂY HỆ TỔNG

```
Muôn Nơi · Human Life OS

┌── Lớp A · Public Shell
│   ├── muonnoi.org
│   ├── docs.muonnoi.org
│   └── verify.muonnoi.org
│
├── Lớp B · Social + Life Quest
│   ├── app.muonnoi.org
│   ├── ai.muonnoi.org
│   ├── chochoi.muonnoi.org      [Hub, M4+]
│   ├── dulich.muonnoi.org        ★ Priority 1 (M1)
│   ├── hoctap.muonnoi.org        ★ Priority 2 (M2-3)
│   ├── family.muonnoi.org        ★ Priority 3 (M4-6)
│   ├── suckhoe.muonnoi.org       (M7-9)
│   ├── lamviec.muonnoi.org/quest/ (M7-9)
│   ├── sangtao.muonnoi.org       (M10-12)
│   └── congdong.muonnoi.org      (M10-12)
│
├── Lớp C · Operator / Civic OS
│   ├── lamviec.muonnoi.org/       [B2B Operator Gateway, đã build]
│   └── 12 Civilization Domains
│
├── Lớp D · Backend Core
│   ├── api.muonnoi.org
│   ├── api.ai.muonnoi.org
│   ├── api.flow.iai.one
│   └── api.ai.iai.one
│
└── Ecosystem (long-term)
    ├── nhachung.muonnoi.org
    └── dautu.muonnoi.org
```

---

## 23. NEXT STEPS

### 23.1 Files cần tạo tiếp (sau master plan này)

```
1. DEV_HANDOFF_DULICH_MUONNOI_30_DAY_MVP.md   ★ tạo cùng master plan này
2. QUEST_TAXONOMY_DULICH_DALAT_V1.md           tuần 1
3. PROOF_AND_REWARD_RULES.md                   tuần 1
4. HOST_VERIFICATION_AND_SAFETY_POLICY.md      tuần 1
5. MISSION_ENGINE_SCHEMA.sql                   tuần 2
6. MISSION_ENGINE_API_CONTRACT.md              tuần 2
7. QUEST_UI_FLOW_SPEC.md                       tuần 2
8. ADMIN_PANEL_SPEC.md                         tuần 2
```

### 23.2 Tích hợp ngay với muonnoi.org

```
apps/web/public/quests/index.html               tuần 1 (1 page intro)
apps/web/public/roadmap/index.html              update Phase 5
apps/web/public/ecosystem/index.html            add Life Quest Layer
apps/web/public/guide/index.html                add Quest guide
apps/web/public/security/index.html             add proof + host + child safety
```

### 23.3 Câu chốt cho team

> **Muôn Nơi không xây game để giữ người trong màn hình. Muôn Nơi xây nhiệm vụ đời sống để đưa người ra thế giới thật, gặp người thật, học điều thật, làm việc thật và tạo giá trị thật.**

---

## 24. PHỤ LỤC

### 24.1 Glossary

| Term | Meaning |
|---|---|
| Life Quest OS | Hệ trò chơi đời sống Muôn Nơi |
| Quest | Nhiệm vụ đời sống có proof |
| Proof | Bằng chứng hoàn thành (text/photo/GPS/video/host signature) |
| Receipt | Proof có hash, xuất khẩu được dưới dạng VC |
| Local Host | Người dân địa phương verified KYC tier 3 |
| Senior Teacher | Người mở Lớp X thành công ≥3 lần rating 4.5★+ |
| Family Pod | Nhóm gia đình tối đa 8 người |
| City Captain | Community leader 1 city ở Game Cồng/Thành Phố |
| Quest Curator | Người thiết kế quest, hưởng % từ sponsor |
| Civic OS | Civilization Operating System (Lớp C, lamviec.muonnoi.org) |
| VC | Verifiable Credential (W3C standard) |
| Trust Score | Reputation xuất khẩu cross-platform |
| Impact Score | Civic contribution credential |
| XP/Skill | Phi tài chính, không đổi tiền |
| Credit | Đổi voucher, không đổi USD |
| Earning | USD/VND thật từ giá trị thật |

### 24.2 Sáu nguyên tắc thiết kế bắt buộc

1. **Proof là gốc.** Không proof, không reward.
2. **Real-world output thắng screen time.**
3. **Không token mới.** Không bao giờ.
4. **Không hứa "ai chơi cũng có tiền".**
5. **Privacy-first di sản từ Muôn Nơi.**
6. **Wellbeing cap.** User tự đặt giới hạn, có Streak Freeze.

### 24.3 Sáu khao khát phổ quát

Mỗi hệ phải đánh trúng ≥2 trong 6:

1. Khao khát có ý nghĩa
2. Khao khát trưởng thành
3. Khao khát được công nhận
4. Khao khát kết nối
5. Khao khát khám phá
6. Khao khát tạo ra

### 24.4 Bốn cơ sở khoa học hành vi

- Self-Determination Theory (autonomy + competence + relatedness)
- Flow Theory (độ khó vừa khít)
- Octalysis (4-6 trong 8 động lực)
- Hooked Model + Real Investment (KHÔNG chỉ time-in-app)

---

**Document version:** v1.0 FINAL
**Date:** 2026-05-11
**Status:** APPROVED for dev handoff
**Prepared for:** Trần Hà Tâm · Muôn Nơi · VIET CAN NEW CORP

**Câu chốt cuối:**

> Hướng tốt nhất không phải "5-10 game để ai cũng kiếm tiền".
> Hướng tốt nhất là 7 hệ nhiệm vụ đời sống giúp mọi người sống tốt hơn, học tốt hơn, đi nhiều hơn, làm được việc thật hơn, kết nối gia đình và cộng đồng sâu hơn — tiền chỉ xuất hiện khi có giá trị thật được tạo ra.
